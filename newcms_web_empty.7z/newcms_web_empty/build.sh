#!/bin/bash
. ~/.profile
. ~/.bashrc
. ~/.nvm/nvm.sh

nvm use 8
npm install
npm run build
PKG_VERSION=`node -p "require('./package.json').version"`
docker build -t registry.cn-beijing.aliyuncs.com/sinosoft_poc/cms-web:v$PKG_VERSION .
docker push registry.cn-beijing.aliyuncs.com/sinosoft_poc/cms-web:v$PKG_VERSION
#docker save -o cms-web.tar 192.168.0.7:5000/cms-web:v$PKG_VERSION
