import * as services from '@/services/api';
import { message } from 'antd';

export default {
  namespace: 'virtual',

  state: {
    currView: 'home',
    currData: {},
    op: '',
    data: { list: [], pagination: [] },
    callData: { list: [], pagination: [] },
    caseData: { list: [], pagination: [] },
    queryPara: {},
    isSimpleQuery: true,
  },

  effects: {
    *fetch({ queryPara }, { call, put }) {
      const response = yield call(services.get, '/api/la-virtual-projects', queryPara);
      yield put({
        type: 'save',
        payload: response,
        queryPara,
      });
    },
    *fetchCall({ queryPara }, { call, put }) {
      const response = yield call(services.get, '/api/la-v-project-to-calls', queryPara);
      yield put({
        type: 'saveCall',
        payload: response,
        queryPara,
      });
    },
    *fetchCase({ queryPara }, { call, put }) {
      const response = yield call(services.get, '/api/la-v-project-to-cases', queryPara);
      yield put({
        type: 'saveCase',
        payload: response,
        queryPara,
      });
    },
    *add({ payload, callback }, { call, put }) {
      const response = yield call(services.post, '/api/la-virtual-projects/add', payload);
      if (response) {
        yield put({
          type: 'openView',
          view: 'home',
          currData: response,
        });
        message.success('添加成功！');
      }
      if (callback) callback();
    },
    *update({ payload, callback }, { call, put }) {
      const response = yield call(services.post, '/api/la-virtual-projects/update', payload);
      if (response) {
        message.success('修改成功！');
        yield put({
          type: 'fetch',
          queryPara: {},
        });
      }
      if (callback) callback();
    },
    *delete({ payload, callback }, { call }) {
      const response = yield call(services.del, '/api/la-virtual-projects/delete', payload);
      if (response) {
        message.success('删除成功！');
        // yield put({
        //   type: 'fetch',
        //   queryPara: {},
        // });
      }
      if (callback) callback();
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data: action.payload || state.data,
        queryPara: action.queryPara || state.queryPara,
        currData: action.currData || state.currData,
      };
    },
    saveCall(state, action) {
      return {
        ...state,
        callData: action.payload || state.callData,
        queryPara: action.queryPara || state.queryPara,
      };
    },
    saveCase(state, action) {
      return {
        ...state,
        caseData: action.payload || state.caseData,
        queryPara: action.queryPara || state.queryPara,
      };
    },
    switchQuery(state) {
      return {
        ...state,
        isSimpleQuery: !state.isSimpleQuery,
      };
    },
    openView(state, action) {
      return {
        ...state,
        currView: action.view,
        currData: action.currData || state.currData,
        op: action.op || state.op,
      };
    },
    resetTable(state) {
      return {
        ...state,
        data: { list: [], pagination: [] },
        queryPara: {},
      };
    },
  },
};
