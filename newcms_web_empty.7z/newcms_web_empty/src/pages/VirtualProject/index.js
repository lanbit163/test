import React, { PureComponent } from 'react';
import { connect } from 'dva';
import Home from './home';
import Edit from './edit';

// 获取model.js中的数据
@connect(({ virtual, loading }) => ({
  virtual,
  loading: loading.models.virtual,
}))
class Index extends PureComponent {
  componentDidMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'virtual/openView',
      view: 'home',
    });
  }

  // es6写法
  getView = () => {
    // 用props 获取connect中的数据
    const {
      virtual: { currView },
    } = this.props;

    // let 定义变量 const 定义常量 <Home /> 自定义标签
    let result = <Home />;
    if (currView === 'edit') {
      result = <Edit />;
    }

    return result;
  };

  render() {
    return <div>{this.getView()}</div>;
  }
}

export default Index;
