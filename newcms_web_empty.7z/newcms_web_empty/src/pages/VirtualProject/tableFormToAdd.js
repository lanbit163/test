import React, { PureComponent, Fragment } from 'react';
import { Table, Button, message, Popconfirm, Divider, Input } from 'antd';
import isEqual from 'lodash/isEqual';
import { connect } from 'dva';
import { formatMessage } from 'umi/locale';

import styles from './styles/tableForm.less';

@connect(({ config, codeselect, virtual }) => ({
  config,
  codeselect,
  virtual,
}))
class TableForm2 extends PureComponent {
  index = 0;

  cacheOriginData = {};

  constructor(props) {
    super(props);

    this.state = {
      data: [],
      loading: false,
      /* eslint-disable-next-line react/no-unused-state */
      value: props.value,
    };
  }

  static getDerivedStateFromProps(nextProps, preState) {
    if (isEqual(nextProps.value, preState.value)) {
      return null;
    }
    return {
      data: nextProps.value,
      value: nextProps.value,
    };
  }

  getRowByKey(key, newData) {
    const { data } = this.state;
    return (newData || data).filter(item => item.key === key)[0];
  }

  toggleEditable = (e, key) => {
    e.preventDefault();
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    const target = this.getRowByKey(key, newData);
    if (target) {
      // 进入编辑状态时保存原始数据
      if (!target.editable) {
        this.cacheOriginData[key] = { ...target };
      }
      target.editable = !target.editable;
      this.setState({ data: newData });
    }
  };

  newMember = () => {
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    newData.push({
      key: `NEW_TEMP_ID_${this.index}`,
      projectCode: '',
      projectName: '',
      // v1: [],
      editable: true,
      isNew: true,
    });
    this.index += 1;
    this.setState({ data: newData });
  };

  remove(key) {
    const { data } = this.state;
    const { onChange } = this.props;
    const newData = data.filter(item => item.key !== key);
    this.setState({ data: newData });
    onChange(newData);
  }

  handleKeyPress(e, key) {
    if (e.key === 'Enter') {
      this.saveRow(e, key);
    }
  }

  handleFieldChange(e, fieldName, key) {
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    const target = this.getRowByKey(key, newData);
    if (target) {
      target[fieldName] = e.target ? e.target.value : e;
      this.setState({ data: newData });
    }
  }

  saveRow(e, key) {
    e.persist();
    this.setState({
      loading: true,
    });
    setTimeout(() => {
      if (this.clickedCancel) {
        this.clickedCancel = false;
        return;
      }
      const target = this.getRowByKey(key) || {};
      if (!target.projectName) {
        message.error('记录不完整，请检查。');
        e.target.focus();
        this.setState({
          loading: false,
        });
        return;
      }
      delete target.isNew;
      this.toggleEditable(e, key);
      const { data } = this.state;
      const { onChange } = this.props;
      onChange(data);
      this.setState({
        loading: false,
      });
    }, 100);
  }

  cancel(e, key) {
    this.clickedCancel = true;
    e.preventDefault();
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    const target = this.getRowByKey(key, newData);
    if (this.cacheOriginData[key]) {
      Object.assign(target, this.cacheOriginData[key]);
      delete this.cacheOriginData[key];
    }
    target.editable = false;
    this.setState({ data: newData });
    this.clickedCancel = false;
  }

  render() {
    const { config } = this.props;

    const columns = [
      // {
      //   title: formatMessage({ id: 'virtual.id' }),
      //   dataIndex: 'id',
      //   key: 'id',
      //   align: config.tableColAlign,
      //   render: (text, record) => {
      //     if (record.editable) {
      //       return (
      //         <Input
      //           value={text}
      //           readOnly
      //           autoFocus
      //           onChange={e => this.handleFieldChange(e, 'id', record.key)}
      //           onKeyPress={e => this.handleKeyPress(e, record.key)}
      //           placeholder={formatMessage({ id: 'virtual.id' })}
      //         />
      //       );
      //     }
      //     return text;
      //   },
      // },
      {
        title: formatMessage({ id: 'virtual.code' }),
        dataIndex: 'projectCode',
        key: 'projectCode',
        align: config.tableColAlign,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                disabled
                onChange={e => this.handleFieldChange(e, 'projectCode', record.key)}
                onKeyPress={e => this.handleKeyPress(e, record.key)}
                placeholder={formatMessage({ id: 'virtual.code' })}
              />
            );
          }
          return text;
        },
      },
      {
        title: formatMessage({ id: 'virtual.name' }),
        dataIndex: 'projectName',
        key: 'projectName',
        align: config.tableColAlign,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                autoFocus
                onChange={e => this.handleFieldChange(e, 'projectName', record.key)}
                onKeyPress={e => this.handleKeyPress(e, record.key)}
                placeholder={formatMessage({ id: 'virtual.name' })}
              />
            );
          }
          return text;
        },
      },
      // {
      //   title: formatMessage({ id: 'virtual.status' }),
      //   dataIndex: 'v1',
      //   key: 'v1',
      //   width: '20%',
      //   align: config.tableColAlign,
      //   render: (text, record) => {
      //     if (record.editable) {
      //       return (
      //         <Select
      //           value={text}
      //           autoFocus
      //           allowClear
      //           onChange={e => this.handleFieldChange(e, 'v1', record.key)}
      //           onKeyPress={e => this.handleKeyPress(e, record.key)}
      //           placeholder={formatMessage({ id: 'virtual.status' })}
      //         >
      //           {codeselect.projectV1.map(item => (
      //             <Select.Option key={item.code}>{item.codeName}</Select.Option>
      //           ))}
      //         </Select>
      //       );
      //     }
      //     let text2 = '';
      //     Object.keys(codeselect.projectV1).map(index => {
      //       if (codeselect.projectV1[index].code === text) {
      //         text2 = codeselect.projectV1[index].codeName;
      //       }
      //       return text2;
      //     });
      //     return text2;
      //   },
      // },
      {
        title: '操作',
        dataIndex: 'action',
        key: 'action',
        align: config.tableColAlign,
        render: (text, record) => {
          const { loading } = this.state;
          if (!!record.editable && loading) {
            return null;
          }
          if (record.editable) {
            if (record.isNew) {
              return (
                <span>
                  <a onClick={e => this.saveRow(e, record.key)}>添加</a>
                  <Divider type="vertical" />
                  <Popconfirm title="是否要删除此行？" onConfirm={() => this.remove(record.key)}>
                    <a>删除</a>
                  </Popconfirm>
                </span>
              );
            }
            return (
              <span>
                <a
                  onClick={e => {
                    this.saveRow(e, record.key);
                  }}
                >
                  保存
                </a>
                <Divider type="vertical" />
                <a onClick={e => this.cancel(e, record.key)}>取消</a>
              </span>
            );
          }
          return (
            <span>
              <a onClick={e => this.toggleEditable(e, record.key)}>编辑</a>
              <Divider type="vertical" />
              <Popconfirm title="是否要删除此行？" onConfirm={() => this.remove(record.key)}>
                <a>删除</a>
              </Popconfirm>
            </span>
          );
        },
      },
    ];

    const { loading, data } = this.state;

    return (
      <Fragment>
        <Table
          loading={loading}
          columns={columns}
          size={config.tablesize}
          bordered={config.tableboard}
          dataSource={data}
          pagination={false}
          rowClassName={record => (record.editable ? styles.editable : '')}
        />
        <Button
          style={{ width: '100%', marginTop: 16, marginBottom: 8 }}
          type="dashed"
          onClick={this.newMember}
          icon="plus"
        >
          添加
        </Button>
      </Fragment>
    );
  }
}

export default TableForm2;
