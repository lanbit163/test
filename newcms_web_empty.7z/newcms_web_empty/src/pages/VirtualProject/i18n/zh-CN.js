export default {
  'virtual.id': '序号',
  'virtual.message': '虚拟项目信息',
  'virtual.code': '虚拟项目编码',
  'virtual.code.001': '1号项目',
  'virtual.code.002': '2号项目',
  'virtual.name': '虚拟项目名称',
  'virtual.status': '状态',
  'virtual.isConnect.0': '否',
  'virtual.isConnect.1': '是',
  'virtual.home.title': '虚拟项目维护',
  'placeholder.virtual.code': '请选择项目编码',

  'placeholder.virtual.name': '请填写项目名称',
  'virtual.createby': '操作人',
  'virtual.table.operate': '操作',
  'virtual.home.add': '新增',
};
