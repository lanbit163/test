import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { Card, Icon, Form, Button, Row, Col } from 'antd';
import { FormattedMessage } from 'umi/locale';
import PageHeaderWrapper from '@/components/PageHeaderWrapper';
// import StandardTable from '@/components/StandardTable';
import TableForm from './TableForm';
import QueryAdvance from './queryAdvance';
import styles from './styles/home.less';

// 获取model.js 文件中reducers的储存的数据
@connect(({ virtual, config, loading, codeselect }) => ({
  virtual,
  config,
  codeselect,
  loading: loading.models.virtual,
}))
@Form.create()
class Home extends PureComponent {
  render() {
    const {
      form: { getFieldDecorator },
      virtual: { data },
      config,
      dispatch,
      loading,
    } = this.props;

    return (
      <PageHeaderWrapper title={<FormattedMessage id="virtual.home.title" />}>
        <Card
          bordered={config.cardboard}
          size={config.cardsize}
          title={
            <div>
              <Icon type="caret-right" />
              <FormattedMessage id="global.query.title" />
            </div>
          }
        >
          <div className={styles.tableListForm}>
            <QueryAdvance />
          </div>
        </Card>
        <Row style={{ marginBottom: 8, marginTop: 8 }}>
          <Col span={24} style={{ textAlign: 'right' }}>
            <Button
              style={{ marginLeft: 800, float: 'right' }}
              type="primary"
              disabled={loading}
              onClick={() =>
                dispatch({
                  type: 'virtual/openView',
                  view: 'edit',
                  op: 'add',
                })
              }
            >
              <FormattedMessage id="global.add" />
            </Button>
          </Col>
        </Row>
        <Card
          bordered={config.cardboard}
          size={config.cardsize}
          title={
            <div>
              <Icon type="caret-right" />
              <FormattedMessage id="global.result.title" />
            </div>
          }
        >
          {getFieldDecorator('members', {
            initialValue: data.list,
          })(<TableForm />)}
        </Card>
      </PageHeaderWrapper>
    );
  }
}

export default Home;
