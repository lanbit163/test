import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { FormattedMessage } from 'umi/locale';
import { Form, message, Card, Row, Col, Button } from 'antd';
import PageHeaderWrapper from '@/components/PageHeaderWrapper';
import TableForm2 from './tableFormToAdd';
import styles from './styles/edit.less';

@connect(({ virtual, global, loading }) => ({
  virtual,
  global,
  loading: loading.models.virtual,
}))
@Form.create()
class EditForm extends PureComponent {
  handleSubmit = e => {
    const { dispatch, form } = this.props;
    e.preventDefault();

    form.validateFieldsAndScroll(err => {
      const alldata = {};
      alldata.virtualList = form.getFieldValue('addMembers');

      if (
        alldata.virtualList === undefined ||
        alldata.virtualList.length === undefined ||
        (alldata.virtualList.length !== undefined && alldata.virtualList.length === 0)
      ) {
        message.warn('没有需要保存的数据，请先添加！');
        return;
      }
      if (!err) {
        dispatch({
          type: 'virtual/add',
          payload: alldata,
        });
      }
    });
  };

  render() {
    const {
      form: { getFieldDecorator },
      loading,
      dispatch,
    } = this.props;
    return (
      <PageHeaderWrapper title={<FormattedMessage id="global.add" />}>
        <Form
          onSubmit={this.handleSubmit}
          style={{ marginTop: 8 }}
          className={styles.tableListForm}
        >
          {getFieldDecorator('addMembers', {})(<TableForm2 />)}
          <Card>
            <Row>
              <Col span={24} style={{ textAlign: 'center' }}>
                <span>
                  <Button type="primary" htmlType="submit" disabled={loading}>
                    <FormattedMessage id="global.save" />
                  </Button>
                  <Button
                    style={{ marginLeft: 8 }}
                    disabled={loading}
                    onClick={() => dispatch({ type: 'virtual/openView', view: 'home' })}
                  >
                    <FormattedMessage id="global.closeup" />
                  </Button>
                </span>
              </Col>
            </Row>
          </Card>
        </Form>
      </PageHeaderWrapper>
    );
  }
}

export default EditForm;
