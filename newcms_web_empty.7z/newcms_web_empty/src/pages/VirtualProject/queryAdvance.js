import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { Form, Row, Col, Select, Button, Input } from 'antd';
import { formatMessage, FormattedMessage } from 'umi/locale';

const FormItem = Form.Item;

@connect(({ virtual, loading, codeselect }) => ({
  virtual,
  codeselect,
  loading: loading.models.virtual,
}))
@Form.create()
class Query extends PureComponent {
  componentDidMount() {
    const { dispatch } = this.props;
    // 初始化下拉列表
    dispatch({
      type: 'codeselect/codequery',
      queryPara: {
        codeType: 'projectcode',
      },
    });
    // 清空表格数据
    dispatch({
      type: 'virtual/resetTable',
      queryPara: {},
    });
  }

  handleSearch = e => {
    e.preventDefault();

    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;
      // const values = {
      //   ...fieldsValue,
      //   updatedAt: fieldsValue.updatedAt && fieldsValue.updatedAt.valueOf(),
      // };
      dispatch({
        type: 'virtual/fetch',
        queryPara: fieldsValue,
      });
    });
  };

  handleFormReset = () => {
    const { form, dispatch } = this.props;
    form.resetFields();
    dispatch({
      type: 'virtual/resetTable',
      queryPara: {},
    });
  };

  render() {
    const {
      // codeselect,
      form: { getFieldDecorator },
      loading,
    } = this.props;
    return (
      <Form onSubmit={this.handleSearch} layout="inline">
        <Row gutter={{ md: 8, lg: 24, xl: 48 }}>
          <Col md={8} sm={24}>
            <FormItem label={<FormattedMessage id="virtual.code" />}>
              {getFieldDecorator('projectCode_equals', { initialValue: [] })(
                <Select
                  showSearch
                  allowClear
                  style={{ width: 200 }}
                  placeholder={formatMessage({ id: 'placeholder.virtual.code' })}
                  optionFilterProp="children"
                  filterOption={(input, option) =>
                    option.props.children.toString().indexOf(input) >= 0
                  }
                />
              )}
            </FormItem>
          </Col>
          <Col md={8} sm={24}>
            <FormItem label={<FormattedMessage id="virtual.name" />}>
              {getFieldDecorator('projectName_contains', { initialValue: [] })(
                <Input placeholder={formatMessage({ id: 'placeholder.virtual.name' })} />
              )}
            </FormItem>
          </Col>
        </Row>
        <div style={{ overflow: 'hidden' }}>
          <div style={{ marginBottom: 24 }}>
            <Button type="primary" style={{ marginLeft: 700 }} htmlType="submit" disabled={loading}>
              查询
            </Button>
            <Button style={{ marginLeft: 8 }} onClick={this.handleFormReset} disabled={loading}>
              重置
            </Button>
          </div>
        </div>
      </Form>
    );
  }
}

export default Query;
