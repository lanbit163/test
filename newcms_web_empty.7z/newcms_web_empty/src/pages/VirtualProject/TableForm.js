import React, { PureComponent, Fragment } from 'react';
import { Table, Input, message, Popconfirm, Divider } from 'antd';
import isEqual from 'lodash/isEqual';
import { connect } from 'dva';
import { formatMessage } from 'umi/locale';

import styles from './styles/tableForm.less';

@connect(({ config, codeselect, loading, virtual }) => ({
  config,
  codeselect,
  virtual,
  loading: loading.models.virtual,
}))
class TableForm extends PureComponent {
  index = 0;

  cacheOriginData = {};

  constructor(props) {
    super(props);

    this.state = {
      data: props.value,
      loading: false,
      value: props.value,
      editing: false,
    };
  }

  static getDerivedStateFromProps(nextProps, preState) {
    if (isEqual(nextProps.value, preState.value)) {
      return null;
    }
    return {
      data: nextProps.value,
      value: nextProps.value,
    };
  }

  getRowByKey(key, newData) {
    const { data } = this.state;
    return (newData || data).filter(item => item.projectCode === key)[0];
  }

  toggleEditable = (e, key) => {
    e.preventDefault();
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    const target = this.getRowByKey(key, newData);
    if (target) {
      // 进入编辑状态时保存原始数据
      // if (!target.editable) {
      //   this.cacheOriginData[key] = { ...target };
      // }
      // target.editable = !target.editable;
      target.editable = true;
      this.setState({ data: newData, editing: true });
    }
  };

  newMember = () => {
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    newData.push({
      key: `NEW_TEMP_ID_${this.index}`,
      projectCode: '',
      projectName: '',
      // v1:'',
      editable: true,
      isNew: true,
    });
    this.index += 1;
    this.setState({ data: newData });
  };

  deleteProject = record => {
    const {
      dispatch,
      virtual: { queryPara },
    } = this.props;
    dispatch({
      type: 'virtual/delete',
      payload: record,
      callback: () => {
        dispatch({
          type: 'virtual/fetch',
          queryPara,
        });
      },
    });
  };

  updateProject = record => {
    const {
      dispatch,
      virtual: { queryPara },
    } = this.props;
    dispatch({
      type: 'virtual/update',
      payload: record,
      callback: () => {
        dispatch({
          type: 'virtual/fetch',
          queryPara,
        });
      },
    });
  };

  // 翻页
  queryPage = pagination => {
    const {
      dispatch,
      virtual: { queryPara },
    } = this.props;
    queryPara.page = pagination.current - 1;
    dispatch({
      type: 'virtual/fetch',
      queryPara,
    });
  };

  remove(key) {
    const { data } = this.state;
    const { onChange } = this.props;
    const newData = data.filter(item => item.projectCode !== key);
    this.setState({ data: newData });
    onChange(newData);
  }

  handleKeyPress(e, key) {
    if (e.key === 'Enter') {
      this.saveRow(e, key);
    }
  }

  handleFieldChange(e, fieldName, key) {
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    const target = this.getRowByKey(key, newData);
    if (target) {
      // target[fieldName] = e.target ? e.target.value : e;
      target[fieldName] = e.target.value;
      this.setState({ data: newData });
    }
  }

  saveRow(e, key) {
    e.persist();
    this.setState({
      loading: true,
    });
    setTimeout(() => {
      if (this.clickedCancel) {
        this.clickedCancel = false;
        return;
      }
      const target = this.getRowByKey(key) || {};
      if (!target.projectCode || !target.projectName) {
        // message.error('请填写完整的项目信息！');
        e.target.focus();
        this.setState({
          loading: false,
          editing: false,
        });
        return;
      }
      delete target.isNew;
      // this.toggleEditable(e, key);
      delete target.editable;
      const { data } = this.state;
      const { onChange } = this.props;
      onChange(data);
      this.setState({
        loading: false,
        editing: false,
      });
    }, 100);
  }

  cancel(e, key) {
    this.clickedCancel = true;
    e.preventDefault();
    const { data } = this.state;
    const newData = data.map(item => ({ ...item }));
    const target = this.getRowByKey(key, newData);
    if (this.cacheOriginData[key]) {
      Object.assign(target, this.cacheOriginData[key]);
      delete this.cacheOriginData[key];
    }
    target.editable = false;
    this.setState({ data: newData, editing: false });
    this.clickedCancel = false;
  }

  render() {
    const { config, dispatch, virtual } = this.props;

    const columns = [
      {
        title: formatMessage({ id: 'virtual.code' }),
        dataIndex: 'projectCode',
        key: 'projectCode',
        align: config.tableColAlign,
        width: 150,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                disabled
                onChange={e => this.handleFieldChange(e, 'projectCode', record.projectCode)}
                onKeyPress={e => this.handleKeyPress(e, record.projectCode)}
                placeholder={formatMessage({ id: 'virtual.code' })}
              />
            );
          }
          return text;
        },
      },
      {
        title: formatMessage({ id: 'virtual.name' }),
        dataIndex: 'projectName',
        key: 'projectName',
        align: config.tableColAlign,
        width: 150,
        render: (text, record) => {
          if (record.editable) {
            return (
              <Input
                value={text}
                autoFocus
                onChange={e => this.handleFieldChange(e, 'projectName', record.projectCode)}
                onKeyPress={e => this.handleKeyPress(e, record.projectCode)}
                placeholder={formatMessage({ id: 'virtual.name' })}
              />
            );
          }
          return text;
        },
      },
      // {
      //   title: formatMessage({ id: 'virtual.status' }),
      //   dataIndex: 'v1',
      //   key: 'v1',
      //   width: '20%',
      //   align: config.tableColAlign,
      //   render: (text, record) => {
      //     if (record.editable) {
      //       return (
      //         <Select
      //           value={text}
      //           disabled
      //           onChange={e => this.handleFieldChange(e, 'v1', record.projectCode)}
      //           onKeyPress={e => this.handleKeyPress(e, record.projectCode)}
      //           placeholder={formatMessage({ id: 'virtual.status' })}
      //         >
      //           {codeselect.projectV1.map(item => (
      //             <Select.Option key={item.code}>{item.codeName}</Select.Option>
      //           ))}
      //         </Select>
      //       );
      //     }
      //     let text2 = '';
      //     Object.keys(codeselect.projectV1).map(index => {
      //       if (codeselect.projectV1[index].code === text) {
      //         text2 = codeselect.projectV1[index].codeName;
      //       }
      //       return text2;
      //     });
      //     return text2;
      //   },
      // },
      {
        title: formatMessage({ id: 'email.table.operate' }),
        dataIndex: 'action',
        key: 'action',
        align: config.tableColAlign,
        width: 150,
        render: (text, record) => {
          const { loading } = this.state;
          if (!!record.editable && loading) {
            return null;
          }
          if (record.editable) {
            if (record.isNew) {
              return (
                <span>
                  <a onClick={e => this.saveRow(e, record.projectCode)}>添加</a>
                  <Divider type="vertical" />
                  <Popconfirm
                    title="是否要删除此行？"
                    onConfirm={() => this.remove(record.projectCode)}
                  >
                    <a>删除</a>
                  </Popconfirm>
                </span>
              );
            }
            return (
              <span>
                <a
                  onClick={e => {
                    if (record.projectName == null || record.projectName === '') {
                      message.error('项目名称不能为空！');
                    }
                    if (record.projectName !== null && record.projectName !== '') {
                      this.saveRow(e, record.projectCode);
                      this.updateProject(record);
                    }
                  }}
                >
                  保存
                </a>
                <Divider type="vertical" />
                <a onClick={e => this.cancel(e, record.projectCode)}>删除</a>
              </span>
            );
          }
          return (
            <span>
              <Popconfirm
                title="修改该信息会同时修改相关映射信息，确定吗？"
                onConfirm={e => this.toggleEditable(e, record.projectCode)}
              >
                <a>编辑</a>
              </Popconfirm>
              <Divider type="vertical" />
              <Popconfirm
                title="确认删除该虚拟项目？"
                onConfirm={() => {
                  if (virtual.callData.list.length === 0 && virtual.caseData.list.length === 0) {
                    this.remove(record.projectCode);
                    this.deleteProject(record);
                    message.success('删除成功，请重新查询！');
                  } else {
                    message.error('该虚拟项目已映射，不允许删除！');
                  }
                }}
              >
                <a
                  onClick={() => {
                    dispatch({
                      type: 'virtual/fetchCall',
                      queryPara: { projectCode_equals: record.projectCode },
                    });
                    dispatch({
                      type: 'virtual/fetchCase',
                      queryPara: { projectCode_equals: record.projectCode },
                    });
                  }}
                >
                  删除
                </a>
              </Popconfirm>
            </span>
          );
        },
      },
    ];

    const { loading, data, editing } = this.state;
    const dataSource = editing ? data : virtual.data.list;
    return (
      <Fragment>
        <Table
          loading={loading}
          columns={columns}
          size={config.tablesize}
          bordered={config.tableboard}
          dataSource={dataSource}
          pagination={false}
          scroll={{ y: 240 }}
          onChange={this.queryPage}
          rowKey="virtual"
          rowClassName={record => (record.editable ? styles.editable : '')}
        />
      </Fragment>
    );
  }
}

export default TableForm;
