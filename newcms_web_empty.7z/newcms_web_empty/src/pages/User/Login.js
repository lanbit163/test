import React, { Component } from 'react';
import { connect } from 'dva';
import { formatMessage, FormattedMessage } from 'umi/locale';
import { Form, Alert, Input, Button } from 'antd';
import name from '../../layouts/img/yonghuming_lan.png';
import psw from '../../layouts/img/mima_lan.png';
import styles from './Login.less';

const FormItem = Form.Item;

@connect(({ login, loading }) => ({
  login,
  submitting: loading.effects['login/login'],
}))
@Form.create()
class LoginPage extends Component {
  // state = {
  //   type: 'account',
  //   autoLogin: true,
  // };

  componentWillMount() {
    localStorage.setItem('umi_locale', 'zh-CN');
  }

  // onTabChange = type => {
  //   this.setState({ type });
  // };

  onGetCaptcha = () =>
    new Promise((resolve, reject) => {
      this.loginForm.validateFields(['mobile'], {}, (err, values) => {
        if (err) {
          reject(err);
        } else {
          const { dispatch } = this.props;
          dispatch({
            type: 'login/getCaptcha',
            payload: values.mobile,
          })
            .then(resolve)
            .catch(reject);
        }
      });
    });

  // handleSubmit = (err, values) => {
  //   const { type } = this.state;
  //   if (!err) {
  //     const { dispatch } = this.props;
  //     dispatch({
  //       type: 'login/login',
  //       payload: {
  //         ...values,
  //         type,
  //       },
  //     });
  //   }
  // };

  handleSubmit = e => {
    e.preventDefault();

    const { dispatch, form } = this.props;
    form.validateFields((err, fieldsValue) => {
      if (err) return;

      // const values = {
      //   ...fieldsValue,
      //   updatedAt: fieldsValue.updatedAt && fieldsValue.updatedAt.valueOf(),
      // };
      dispatch({
        type: 'login/login',
        payload: {
          ...fieldsValue,
          type: 'login/login',
        },
      });
    });
  };

  // changeAutoLogin = e => {
  //   this.setState({
  //     autoLogin: e.target.checked,
  //   });
  // };

  renderMessage = content => (
    <Alert style={{ marginBottom: 24 }} message={content} type="error" showIcon />
  );

  render() {
    // alert("render")
    const {
      // login,
      // submitting,
      form: { getFieldDecorator },
    } = this.props;
    // const { type, autoLogin } = this.state;
    return (
      <div>
        <div className={styles.main}>
          <Form onSubmit={this.handleSubmit} layout="inline">
            <FormItem className={styles.spanMargin}>
              {getFieldDecorator('username', {
                initialValue: '',
                rules: [{ required: true, message: 'Please input your username!' }],
              })(
                <Input
                  placeholder={formatMessage({ id: 'app.login.username' })}
                  addonBefore={<img src={name} alt="" />}
                  allowClear
                  style={{ width: 250 }}
                />
              )}
            </FormItem>
            <FormItem className={styles.spanMargin}>
              {getFieldDecorator('password', {
                initialValue: '',
                rules: [{ required: true, message: 'Please input your password!' }],
              })(
                <Input.Password
                  placeholder={formatMessage({ id: 'app.login.password' })}
                  allowClear
                  style={{ width: 250 }}
                  addonBefore={<img src={psw} alt="" />}
                />
              )}
            </FormItem>

            {/* <div style={{ padding: '0 5px' }}>
              <Checkbox checked={autoLogin} onChange={this.changeAutoLogin}>
                <FormattedMessage id="app.login.remember-me" />
              </Checkbox>
              <a style={{ float: 'right', color: '#434ffa' }} href="">
                <FormattedMessage id="app.login.forgot-password" />
              </a>
          </div> */}
            <div style={{ display: 'flex', justifyContent: 'space-around', width: '100%' }}>
              <Button type="primary" htmlType="submit" style={{ width: '100%', marginTop: 20 }}>
                <FormattedMessage id="app.login.login" />
              </Button>
            </div>
          </Form>
        </div>
      </div>
    );
  }
}

export default LoginPage;
