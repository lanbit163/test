import React, { PureComponent } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import { FormattedMessage } from 'umi/locale';
import { Form, Input, Button, Card, DatePicker } from 'antd';
import PageHeaderWrapper from '@/components/PageHeaderWrapper';

const FormItem = Form.Item;

@connect(({ dateseting, loading }) => ({
  dateseting,
  loading: loading.models.dateseting,
}))
@Form.create()
class Index extends PureComponent {
  componentDidMount() {
    const { dispatch } = this.props;
    dispatch({
      type: 'dateseting/fetchcurrentday',
      queryPara: {
        codeType: 'sysDate',
      },
    });
  }

  handleSubmit = e => {
    const { dispatch, form } = this.props;
    e.preventDefault();
    form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        const datatosave = {};
        datatosave.codeType = 'sysDate';
        datatosave.code = values.newSysDate;
        datatosave.codeName = '系统日期';
        form.resetFields();
        dispatch({
          type: 'dateseting/changeDate',
          payload: datatosave,
        });
      }
    });
  };

  rollbackSysdate = () => {
    const { dispatch } = this.props;
    dispatch({
      type: 'dateseting/rollbackDate',
      payload: {},
    });
  };

  render() {
    const {
      loading,
      dateseting: { data },
    } = this.props;

    const {
      form: { getFieldDecorator },
    } = this.props;

    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 },
        md: { span: 10 },
      },
    };

    const submitFormLayout = {
      wrapperCol: {
        xs: { span: 24, offset: 0 },
        sm: { span: 10, offset: 7 },
      },
    };

    return (
      <PageHeaderWrapper>
        <Card bordered={false}>
          <Form onSubmit={this.handleSubmit} style={{ marginTop: 8 }}>
            <FormItem
              {...formItemLayout}
              label={<FormattedMessage id="global.fields.system.oldday" />}
            >
              {getFieldDecorator('curSysDate', {
                initialValue: data[0]
                  ? moment(data[0].code)
                      .utcOffset(0)
                      .format('YYYY-MM-DD HH:mm:ss')
                  : '',
                rules: [
                  {
                    required: false,
                  },
                ],
              })(<Input disabled />)}
            </FormItem>

            <FormItem
              {...formItemLayout}
              label={<FormattedMessage id="global.fields.system.newday" />}
            >
              {getFieldDecorator('newSysDate', {
                rules: [
                  {
                    required: true,
                    // message: formatMessage({ id: 'validation.dateseting.newsysdate.required' }),
                  },
                ],
              })(<DatePicker style={{ width: '100%' }} renderExtraFooter={() => ''} showTime />)}
            </FormItem>

            <FormItem {...submitFormLayout} style={{ marginTop: 32 }}>
              <Button type="primary" htmlType="submit" disabled={loading}>
                <FormattedMessage id="global.save" />
              </Button>
              <Button disabled={loading} style={{ marginLeft: 8 }} onClick={this.rollbackSysdate}>
                <FormattedMessage id="global.fields.system.rollbackday" />
              </Button>
            </FormItem>
          </Form>
        </Card>
      </PageHeaderWrapper>
    );
  }
}

export default Index;
