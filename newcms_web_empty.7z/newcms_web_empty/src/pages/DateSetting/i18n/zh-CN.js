export default {
  'dateseting.oldday': '当前系统日期',
  'dateseting.newday': '调整系统日期',
  'dateseting.edit.title': '系统日期调整',
  'dateseting.rollback.title': '恢复系统日期',
  'dateseting.edit.content':
    '为了测试方便增加此功能，保存后提交到数据库，后台增加判断条件，可以从数据库库中取出存储的时间代替当前时间',
  'validation.dateseting.newsysdate.required': '调增后系统日期不能为空',
};
