import * as services from '@/services/api';

export default {
  namespace: 'dateseting',

  state: {
    data: {},
  },

  effects: {
    *fetchcurrentday({ queryPara }, { call, put }) {
      const response = yield call(services.post, '/api/ld-codes/codequery', queryPara);
      if (response) {
        yield put({
          type: 'save',
          payload: response,
        });
      }
    },
    *changeDate({ payload }, { call, put }) {
      const response = yield call(services.post, '/api/ld-codes', payload);
      if (response) {
        yield put({
          type: 'fetchcurrentday',
          queryPara: { codeType: 'sysDate' },
        });
      }
    },
    *rollbackDate({ payload }, { call, put }) {
      yield call(services.get, '/api/ld-codes/codedelte/sysDate', payload);
      //  这里怎们不走回调了呢
      yield put({
        type: 'fetchcurrentday',
        queryPara: { codeType: 'sysDate' },
      });
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data: action.payload || state.data,
      };
    },
  },
};
