import dva from 'dva';
import { Component } from 'react';
import createLoading from 'dva-loading';
import history from '@tmp/history';

let app = null;

export function _onCreate() {
  const plugins = require('umi/_runtimePlugin');
  const runtimeDva = plugins.mergeConfig('dva');
  app = dva({
    history,
    
    ...(runtimeDva.config || {}),
    ...(window.g_useSSR ? { initialState: window.g_initialData } : {}),
  });
  
  app.use(createLoading());
  (runtimeDva.plugins || []).forEach(plugin => {
    app.use(plugin);
  });
  
  app.model({ namespace: 'approve', ...(require('E:/NEW_CMS/newcms_web_empty/src/models/approve.js').default) });
app.model({ namespace: 'codeselect', ...(require('E:/NEW_CMS/newcms_web_empty/src/models/codeselect.js').default) });
app.model({ namespace: 'config', ...(require('E:/NEW_CMS/newcms_web_empty/src/models/config.js').default) });
app.model({ namespace: 'detailsUp', ...(require('E:/NEW_CMS/newcms_web_empty/src/models/detailsUp.js').default) });
app.model({ namespace: 'global', ...(require('E:/NEW_CMS/newcms_web_empty/src/models/global.js').default) });
app.model({ namespace: 'list', ...(require('E:/NEW_CMS/newcms_web_empty/src/models/list.js').default) });
app.model({ namespace: 'login', ...(require('E:/NEW_CMS/newcms_web_empty/src/models/login.js').default) });
app.model({ namespace: 'managecom', ...(require('E:/NEW_CMS/newcms_web_empty/src/models/managecom.js').default) });
app.model({ namespace: 'menu', ...(require('E:/NEW_CMS/newcms_web_empty/src/models/menu.js').default) });
app.model({ namespace: 'project', ...(require('E:/NEW_CMS/newcms_web_empty/src/models/project.js').default) });
app.model({ namespace: 'pubfile', ...(require('E:/NEW_CMS/newcms_web_empty/src/models/pubfile.js').default) });
app.model({ namespace: 'rowSelection', ...(require('E:/NEW_CMS/newcms_web_empty/src/models/rowSelection.js').default) });
app.model({ namespace: 'setting', ...(require('E:/NEW_CMS/newcms_web_empty/src/models/setting.js').default) });
app.model({ namespace: 'user', ...(require('E:/NEW_CMS/newcms_web_empty/src/models/user.js').default) });
  return app;
}

export function getApp() {
  return app;
}

export class _DvaContainer extends Component {
  render() {
    const app = getApp();
    app.router(() => this.props.children);
    return app.start()();
  }
}
