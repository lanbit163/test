import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/lib/renderRoutes';
import history from '@tmp/history';
import RendererWrapper0 from 'E:/NEW_CMS/newcms_web_empty/src/pages/.umi/LocaleWrapper.jsx'
import _dvaDynamic from 'dva/dynamic'

const Router = require('dva/router').routerRedux.ConnectedRouter;

const routes = [
  {
    "path": "/user",
    "component": __IS_BROWSER
    ? _dvaDynamic({
      
      component: () => import(/* webpackChunkName: "layouts__UserLayout" */'../../layouts/UserLayout'),
      LoadingComponent: require('E:/NEW_CMS/newcms_web_empty/src/components/PageLoading/index').default,
    })
    : require('../../layouts/UserLayout').default,
    "routes": [
      {
        "path": "/user",
        "redirect": "/user/login",
        "exact": true
      },
      {
        "path": "/user/login",
        "name": "login",
        "component": __IS_BROWSER
    ? _dvaDynamic({
      app: require('@tmp/dva').getApp(),
models: () => [
  import(/* webpackChunkName: 'p__User__models__register.js' */'E:/NEW_CMS/newcms_web_empty/src/pages/User/models/register.js').then(m => { return { namespace: 'register',...m.default}})
],
      component: () => import(/* webpackChunkName: "p__User__Login" */'../User/Login'),
      LoadingComponent: require('E:/NEW_CMS/newcms_web_empty/src/components/PageLoading/index').default,
    })
    : require('../User/Login').default,
        "exact": true
      },
      {
        "path": "/user/register",
        "name": "register",
        "component": __IS_BROWSER
    ? _dvaDynamic({
      app: require('@tmp/dva').getApp(),
models: () => [
  import(/* webpackChunkName: 'p__User__models__register.js' */'E:/NEW_CMS/newcms_web_empty/src/pages/User/models/register.js').then(m => { return { namespace: 'register',...m.default}})
],
      component: () => import(/* webpackChunkName: "p__User__Register" */'../User/Register'),
      LoadingComponent: require('E:/NEW_CMS/newcms_web_empty/src/components/PageLoading/index').default,
    })
    : require('../User/Register').default,
        "exact": true
      },
      {
        "path": "/user/register-result",
        "name": "register.result",
        "component": __IS_BROWSER
    ? _dvaDynamic({
      app: require('@tmp/dva').getApp(),
models: () => [
  import(/* webpackChunkName: 'p__User__models__register.js' */'E:/NEW_CMS/newcms_web_empty/src/pages/User/models/register.js').then(m => { return { namespace: 'register',...m.default}})
],
      component: () => import(/* webpackChunkName: "p__User__RegisterResult" */'../User/RegisterResult'),
      LoadingComponent: require('E:/NEW_CMS/newcms_web_empty/src/components/PageLoading/index').default,
    })
    : require('../User/RegisterResult').default,
        "exact": true
      },
      {
        "component": () => React.createElement(require('E:/NEW_CMS/newcms_web_empty/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
      }
    ]
  },
  {
    "path": "/",
    "component": __IS_BROWSER
    ? _dvaDynamic({
      
      component: () => import(/* webpackChunkName: "layouts__BasicLayout" */'../../layouts/BasicLayout'),
      LoadingComponent: require('E:/NEW_CMS/newcms_web_empty/src/components/PageLoading/index').default,
    })
    : require('../../layouts/BasicLayout').default,
    "routes": [
      {
        "path": "/agent",
        "name": "agent",
        "icon": "",
        "routes": [
          {
            "component": () => React.createElement(require('E:/NEW_CMS/newcms_web_empty/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "component": __IS_BROWSER
    ? _dvaDynamic({
      
      component: () => import(/* webpackChunkName: "p__404" */'../404'),
      LoadingComponent: require('E:/NEW_CMS/newcms_web_empty/src/components/PageLoading/index').default,
    })
    : require('../404').default,
        "exact": true
      },
      {
        "component": () => React.createElement(require('E:/NEW_CMS/newcms_web_empty/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
      }
    ]
  },
  {
    "component": () => React.createElement(require('E:/NEW_CMS/newcms_web_empty/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
  }
];
window.g_routes = routes;
const plugins = require('umi/_runtimePlugin');
plugins.applyForEach('patchRoutes', { initialValue: routes });

// route change handler
function routeChangeHandler(location, action) {
  plugins.applyForEach('onRouteChange', {
    initialValue: {
      routes,
      location,
      action,
    },
  });
}
history.listen(routeChangeHandler);
routeChangeHandler(history.location);

export { routes };

export default function RouterWrapper(props = {}) {
  return (
<RendererWrapper0>
          <Router history={history}>
      { renderRoutes(routes, props) }
    </Router>
        </RendererWrapper0>
  );
}
