import { stringify } from 'qs';
import { message } from 'antd';
import { saveAs } from 'file-saver';
import fetch from 'dva/fetch';
import request from '@/utils/request';

export async function queryProjectNotice() {
  return request('/api/project/notice');
}

export async function queryActivities() {
  return request('/api/activities');
}

export async function queryRule(params) {
  return request(`/api/rule?${stringify(params)}`);
}

export async function removeRule(params) {
  return request('/api/rule', {
    method: 'POST',
    body: {
      ...params,
      method: 'delete',
    },
  });
}

export async function addRule(params) {
  return request('/api/rule', {
    method: 'POST',
    body: {
      ...params,
      method: 'post',
    },
  });
}

export async function updateRule(params = {}) {
  return request(`/api/rule?${stringify(params.query)}`, {
    method: 'POST',
    body: {
      ...params.body,
      method: 'update',
    },
  });
}

export async function fakeSubmitForm(params) {
  return request('/api/forms', {
    method: 'POST',
    body: params,
  });
}

export async function fakeChartData() {
  return request('/api/fake_chart_data');
}

export async function queryTags() {
  return request('/api/tags');
}

export async function queryBasicProfile(id) {
  return request(`/api/profile/basic?id=${id}`);
}

export async function queryAdvancedProfile() {
  return request('/api/profile/advanced');
}

export async function queryFakeList(params) {
  return request(`/api/fake_list?${stringify(params)}`);
}

export async function removeFakeList(params) {
  const { count = 5, ...restParams } = params;
  return request(`/api/fake_list?count=${count}`, {
    method: 'POST',
    body: {
      ...restParams,
      method: 'delete',
    },
  });
}

export async function addFakeList(params) {
  const { count = 5, ...restParams } = params;
  return request(`/api/fake_list?count=${count}`, {
    method: 'POST',
    body: {
      ...restParams,
      method: 'post',
    },
  });
}

export async function updateFakeList(params) {
  const { count = 5, ...restParams } = params;
  return request(`/api/fake_list?count=${count}`, {
    method: 'POST',
    body: {
      ...restParams,
      method: 'update',
    },
  });
}

export async function fakeAccountLogin(params) {
  return request('/api/authenticate', {
    method: 'POST',
    body: params,
  });
}

export async function fakeRegister(params) {
  return request('/api/register', {
    method: 'POST',
    body: params,
  });
}

export async function queryNotices(params = {}) {
  return request(`/api/notices?${stringify(params)}`);
}

export async function getFakeCaptcha(mobile) {
  return request(`/api/captcha?mobile=${mobile}`);
}

/**
 common methods
 */

export async function port(url, values, filename) {
  return fetch(url, {
    method: 'POST',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json; charset=utf-8',
      Authorization: `Bearer ${localStorage.getItem('token')}`,
    },
    body: JSON.stringify(values),
  }).then(response => {

    if (response.status !== 200 && response.status !== 201) {
      message.error('出错了，请将错误信息excel反馈给管理员');
    }
    response.blob().then(blob => {
      saveAs(blob, filename);
    });
  });
}

// 前台传Criteria参数的查询导出excel
export async function portExcelCriteria(url, params) {
  const params2 = {};
  Object.keys(params).map(key => {
    if (params[key]) {
      params2[key.replace('_', '.')] = params[key];
    }
    return params2;
  });
  const str = stringify(params2);
  let newUrl = url;
  if (str) {
    newUrl = `${url}?${str}`;
  }

  return fetch(newUrl, {
    method: 'GET',
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json; charset=utf-8',
      Authorization: `Bearer ${localStorage.getItem('token')}`,
    },
  }).then(response => {
    if (response.status !== 200 && response.status !== 201) {
      message.error('导出excel出错');
    } else {
      response.blob().then(blob => {
        saveAs(blob, `${new Date().valueOf()}.xlsx`);
      });
    }
  });
}

export async function upload(url, values) {
  return request(url, {
    method: 'POST',
    body: values,
  });
}

export async function get(url, params) {
  // 下边的这个方法实现key值得转换
  //  约定，在view层写查询表单时用_然后这里把key值替换为.便于后台构建动态查询
  const params2 = {};
  Object.keys(params).map(key => {
    if (params[key]) {
      params2[key.replace('_', '.')] = params[key];
    }
    return params2;
  });

  if (!params2.size) params2.size = 10;
  const str = stringify(params2);
  let newUrl = url;
  if (str) {
    newUrl = `${url}?${str}`;
  }
  return request(newUrl, params2);
}

export async function post(url, values) {
  return request(url, {
    method: 'POST',
    body: {
      ...values,
      method: 'post',
    },
  });
}

export async function put(url, values = {}) {
  // const str = stringify(values);
  // if(str) {
  //   url = `${url}?${str}`;
  // }
  return request(url, {
    method: 'PUT',
    body: {
      ...values,
      method: 'update',
    },
  });
}

export async function del(url, values) {
  return request(`${url}/${values.id}`, {
    method: 'DELETE',
    body: {
      ...values,
      method: 'delete',
    },
  });
}
