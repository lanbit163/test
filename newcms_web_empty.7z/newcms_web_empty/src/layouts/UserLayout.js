import React, { Component } from 'react';
import { connect } from 'dva';
/* eslint-disable*/
import Link from 'umi/link';
import DocumentTitle from 'react-document-title';
import styles from './UserLayout.less';
import getPageTitle from '@/utils/getPageTitle';
import logo from './img/logo.png';
import chahua from './img/chahua.png';
/* eslint-disable */
class UserLayout extends Component {
  render() {
    const {
      children,
      location: { pathname },
      breadcrumbNameMap,
    } = this.props;
    return (
      <DocumentTitle title={getPageTitle(pathname, breadcrumbNameMap)}>
        <div className={styles.container}>
          <div
            style={{
              backgroun: '#fff',
              width: '100%',
              height: '70px',
              margin: '0 auto',
              lineHeight: '70px',
              background: '#fff',
            }}
          >
            <div style={{ width: '1000px', height: '70px', margin: '0 auto' }}>
              <img src={logo} style={{ height: '30px', marginTop: '-7px' }} />
              <span style={{ fontSize: '25px', marginLeft: '10px', color: '#333' }}>
                中科软科技股份有限公司
              </span>
            </div>
          </div>
          <div
            style={{
              width: '900px',
              margin: '0 auto',
              display: 'flex',
              justifyContent: 'space-between',
              height: '100%',
            }}
          >
            <img src={chahua} style={{ height: '100%', width: '250px' }} />
            <div className={styles.content}>
              <div className={styles.top}>
                <div className={styles.header}>
                  <Link to="/">
                    {/*<img width={180} src={require('./img/metlife-china-logo.png')} alt="" />*/}
                    <span className={styles.title} style={{ color: '#048fe2' }}>
                      CMS销售管理系统
                    </span>
                  </Link>
                </div>
              </div>
              {children}
            </div>
          </div>
          <div
            style={{
              background: '#fff',
              width: '100%',
              height: '70px',
              margin: '0 auto',
              lineHeight: '70px',
              color: '#666666',
              textAlign: 'center',
            }}
          >
            Copyright 2019 中科软科技股份有限公司
          </div>
        </div>
      </DocumentTitle>
    );
  }
}

export default connect(({ menu: menuModel }) => ({
  menuData: menuModel.menuData,
  breadcrumbNameMap: menuModel.breadcrumbNameMap,
}))(UserLayout);
