import analysis from './zh-CN/analysis';
import exception from './zh-CN/exception';
import form from './zh-CN/form';
import globalHeader from './zh-CN/globalHeader';
import login from './zh-CN/login';
import menu from './zh-CN/menu';
import monitor from './zh-CN/monitor';
import result from './zh-CN/result';
import settingDrawer from './zh-CN/settingDrawer';
import settings from './zh-CN/settings';
import pwa from './zh-CN/pwa';
import component from './zh-CN/component';
// import global from './zh-CN/globalHeader';
// import role from '@/pages/RoleConfig/i18n/zh-CN';
// import userinfo from '@/pages/UserInfoConfig/i18n/zh-CN';
// import datesetting from '@/pages/DateSetting/i18n/zh-CN';
// import menuinfo from '@/pages/MenuConfig/i18n/zh-CN';
// import menus from '@/pages/menus/i18n/zh-CN';
// import roles from '@/pages/roles/i18n/zh-CN';
// import sysUser from '@/pages/sysUser/i18n/zh-CN';
// import laagGroupInfo from '@/pages/LaagAgentGroupInfo/i18n/zh-CN';
// import adjustAgent from '@/pages/LaagAdjustAgentIndInput/i18n/zh-CN';
// import changeBranchNew from '@/pages/LaagChangeBranchNewInput/i18n/zh-CN';
// import laagBranchGroup from '@/pages/LaagBranchGroupIndQuery/i18n/zh-CN';
// import branchAgent from '@/pages/LaagBranchAgentIndQuery/i18n/zh-CN';
// import recommend from '@/pages/LaagRecommendQuery/i18n/zh-CN';
// import larear from '@/pages/LaagRearRelationIndQuery/i18n/zh-CN';
// import manoeuvre from '@/pages/LaagBranchGroupIndManoeuvreQuery/i18n/zh-CN';
// import recommodify from '@/pages/LaagRecomInitModifyInput/i18n/zh-CN';
// import adjustgrade from '@/pages/LaagAdjustGradeInd/i18n/zh-CN';
// import laagAgentIndInput from '@/pages/LaagAgentIndInput/i18n/zh-CN';
// import agentQuit from '@/pages/LaagAgentQuitManage/i18n/zh-CN';
// import agentRevoke from '@/pages/LaagAgentQuitRevoke/i18n/zh-CN';
// import salaryquery from '@/pages/LaagAgentCommissionQuery/i18n/zh-CN';
// import wageCount from '@/pages/LaagWageCount/i18n/zh-CN';
// import assessAdjust from '@/pages/LaagAssessAdjustInput/i18n/zh-CN';
// import assessConfirm from '@/pages/LaagAssessConfirmInput/i18n/zh-CN';
// import holsInput from '@/pages/LaagHolsInput/i18n/zh-CN';
// import wageConfirm from '@/pages/LaagWageConfirmInput/i18n/zh-CN';
// import indWageCount from '@/pages/LaagIndAgentAssessInput/i18n/zh-CN';
// import assessment from '@/pages/LaagAssessmentResultQuery/i18n/zh-CN';
// import behavinput from '@/pages/LaagBehavInput/i18n/zh-CN';
// import interfaceTest from '@/pages/InterfaceTest/i18n/zh-CN';

// import more resource

export default {
  'navBar.lang': 'interfaceTest',
  'layout.user.link.help': '帮助',
  'layout.user.link.privacy': '隐私',
  'layout.user.link.terms': '条款',
  'app.home.introduce': '介绍',
  'app.forms.basic.title': '基础表单',
  'app.forms.basic.description':
    '表单页用于向用户收集或验证信息，基础表单常见于数据项较少的表单场景。',
  ...analysis,
  ...exception,
  ...form,
  ...globalHeader,
  ...login,
  ...menu,
  ...monitor,
  ...result,
  ...settingDrawer,
  ...settings,
  ...pwa,
  ...component,
  // ...global,
  // ...role,
  // ...userinfo,
  // ...datesetting,
  // ...menuinfo,
  // ...menus,
  // ...roles,
  // ...sysUser,
  // ...laagGroupInfo,
  // ...adjustAgent,
  // ...changeBranchNew,
  // ...branchAgent,
  // ...recommend,
  // ...larear,
  // ...manoeuvre,
  // ...recommodify,
  // ...adjustgrade,
  // ...laagAgentIndInput,
  // ...agentQuit,
  // ...agentRevoke,
  // ...salaryquery,
  // ...wageCount,
  // ...assessAdjust,
  // ...assessConfirm,
  // ...holsInput,
  // ...wageConfirm,
  // ...indWageCount,
  // ...assessment,
  // ...behavinput,
  // ...laagBranchGroup,
  // ...interfaceTest,

  // add more resource
};
