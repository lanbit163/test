export default {
  'agent.name': '名称',
  'agent.agent-code': '代理人编码',
  'agent.birth-day': '出生日期',
  'agent.age': '年龄',
  'agent.validation.name.required': '请输入名称',
  'agent.validation.agent-code.required': '请输入代理人编码',
  'agent.validation.birth-day.required': '请输入出生日期',
  'agent.validation.age.required': '请输入年龄',
};
