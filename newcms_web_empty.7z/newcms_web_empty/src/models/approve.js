import * as services from '@/services/api';
import { message } from 'antd';

export default {
  namespace: 'approve',

  state: {},

  effects: {
    *batchApprove({ payload, namespace, viewname }, { call, put }) {
      const response = yield call(services.post, null, payload);
      if (response.flag !== 'Success') {
        message.error('审核出错');
      } else {
        message.success('审核成功');
        yield put({
          type: `${namespace}/openView`,
          view: viewname,
        });
      }
    },
  },

  reducers: {},
};
