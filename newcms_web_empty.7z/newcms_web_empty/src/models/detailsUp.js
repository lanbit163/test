import * as service from '@/services/api';
import { message } from 'antd/lib/index';

export default {
  namespace: 'detailsUp',

  state: {
    currView: 'home',
    currData: {},
    op: '',
    data: {
      list: [],
      pagination: {},
    },
    dataxm: [],
    data1: {},
    queryPara: {},
    checkUserData: {},
    payno: '',
    batchstate: '',
    checkdate: '',
    isSimpleQuery: true,
  },

  effects: {
    *fetch({ queryPara }, { call, put }) {
      const response = yield call(service.post, '/api/la-charge-batches/findData', queryPara);
      yield put({
        type: 'save',
        payload: response,
        queryPara,
      });
    },
    *fetch1({ payload }, { call, put }) {
      const response = yield call(service.post, '/api/la-charge-batches/findChargeDetail', payload);
      if (response) {
        let zglje = 0;
        let zgljls = 0;
        let ztzxje = 0;
        let ztzxjls = 0;
        // let zcytzje = 0;
        // let zcytzjls = 0;

        for (let i = 0; i < response.list.length; i += 1) {
          zglje += parseFloat(response.list[i].proAmount || 0);
          zgljls += parseFloat(response.list[i].proCount || 0);
          ztzxje += parseFloat(response.list[i].sumAdjustmentAmount || 0);
          ztzxjls += parseFloat(response.list[i].countAdjust || 0);
          // zcytzje += parseFloat(response.list[i].counts);
          // zcytzjls += parseFloat(response.list[i].allChargeMoney);
        }
        response.zglje = zglje;
        response.zgljls = zgljls;
        response.ztzxje = ztzxje;
        response.ztzxjls = ztzxjls;
        // response.zcytzje = zcytzje;
        // response.zcytzjls = zcytzjls;
        yield put({
          type: 'save',
          payload: response,
        });
      }
    },
    *ipt1({ payload }, { call, put }) {
      const response = yield call(service.get, `/api/la-charge-batches/${payload}`, payload);
      yield put({
        type: 'ipt',
        payload: response,
      });
    },
    *findProject({ payload }, { call, put }) {
      const response = yield call(service.post, `/api/la-charge-batches/findProject`, payload);
      yield put({
        type: 'find',
        payload: response,
      });
    },
    // 区间重复校验
    *checkDate({ payload }, { call, put }) {
      const response = yield call(service.post, `/api/la-charge-batches/checkDate`, payload);
      yield put({
        type: 'checkdate',
        payload: response,
      });
    },
    // 业绩试算
    *trial({ queryPara, callback }, { call, put }) {
      const response = yield call(service.post, '/api/la-charge-batches/findCommision', queryPara);
      if (response) {
        let zjls = 0;
        let zje = 0;
        for (let i = 0; i < response.list.length; i += 1) {
          zjls += parseFloat(response.list[i].counts || 0);
          zje += parseFloat(response.list[i].allChargeMoney || 0);
        }
        response.zjls = zjls;
        response.zje = zje;
        yield put({
          type: 'save1',
          payload: response,
          queryPara,
        });
      }
      if (callback) callback();
    },
    // 资金盘盘业绩试算
    *trial1({ queryPara, callback }, { call, put }) {
      const response = yield call(
        service.post,
        '/api/la-commision-charge-pps/findCommisionPP',
        queryPara
      );
      if (response) {
        let zjls = 0;
        let zje = 0;
        for (let i = 0; i < response.list.length; i += 1) {
          zjls += parseFloat(response.list[i].counts || 0);
          zje += parseFloat(response.list[i].allChargeMoney || 0);
        }
        response.zjls = zjls;
        response.zje = zje;
        yield put({
          type: 'save1',
          payload: response,
          queryPara,
        });
      }
      if (callback) callback();
    },
    // 业绩试算页的导出
    *export({ payload }, { call }) {
      // alert(JSON.stringify(payload))
      yield call(service.port, '/api/la-charge-batches/excel', payload, 'laComissionDetail.xlsx');
    },
    // 资金盘片业绩试算的导出
    *export1({ payload }, { call }) {
      // alert(JSON.stringify(payload))
      yield call(
        service.port,
        '/api/la-commision-charge-pps/excel',
        payload,
        'LaCommisionDetailPP.xlsx'
      );
    },
    *userIdCheck({ payload, callback }, { call, put }) {
      const response = yield call(service.post, '/api/la-approval-flows/userIdCheck', payload);
      yield put({
        type: 'setCheckUserData',
        checkUserData: response,
      });
      if (callback) callback();
    },
    *update({ payload }, { call, put }) {
      const response = yield call(service.post, '/api/la-charge-batches/payNo', payload);
      if (response) {
        yield put({
          type: 'payNo',
          payload: response.payNo,
          batchState: response.batchState,
        });
      }
    },
    // 发票关联性校验
    *checkInvoice({ payload }, { call, put }) {
      const response = yield call(service.post, `/api/la-charge-batches/checkInvoice`, payload);
      yield put({
        type: 'checkResult',
        payload: response,
      });
    },
    // 支付申请
    *payApply({ payload, callbcak }, { call }) {
      const response = yield call(service.post, '/api/la-charge-batches/payApplication', payload);
      if (response.flag === 'Success') {
        message.success(response.message);
      } else if (response.flag === 'warning') {
        message.warn(response.message);
      }
      if (callbcak) callbcak();
    },
    // 支付处理
    *payDeal({ payload, callbcak }, { call }) {
      const response = yield call(service.post, '/api/la-charge-batches/payDeal', payload);
      if (response.flag === 'Success') {
        message.success(response.message);
      } else if (response.flag === 'warning') {
        message.warn(response.message);
      }
      if (callbcak) callbcak();
    },
  },

  reducers: {
    save(state, action) {
      return {
        ...state,
        data: action.payload || state.data,
        queryPara: action.queryPara || state.queryPara,
        currData: action.currData || state.currData,
      };
    },
    ipt(state, action) {
      return {
        ...state,
        data1: action.payload || state.data1,
        queryPara: action.queryPara || state.queryPara,
        currData: action.currData || state.currData,
      };
    },
    find(state, action) {
      return {
        ...state,
        dataxm: action.payload || state.dataxm,
        queryPara: action.queryPara || state.queryPara,
        currData: action.currData || state.currData,
      };
    },
    save1(state, action) {
      return {
        ...state,
        data: action.payload || state.data,
        queryPara: action.queryPara || state.queryPara,
        currData: action.currData || state.currData,
      };
    },
    payNo(state, action) {
      return {
        ...state,
        payno: action.payload || state.payno,
        batchstate: action.batchState || state.batchstate,
      };
    },
    checkdate(state, action) {
      return {
        ...state,
        checkdate: action.payload || state.checkdate,
      };
    },
    checkResult(state, action) {
      return {
        ...state,
        checkResult: action.payload || state.checkResult,
      };
    },
    switchQuery(state) {
      return {
        ...state,
        isSimpleQuery: !state.isSimpleQuery,
      };
    },
    openView(state, action) {
      return {
        ...state,
        currView: action.view,
        currData: action.currData || state.currData,
        op: action.op || state.op,
      };
    },
    setCheckUserData(state, action) {
      return {
        ...state,
        checkUserData: action.checkUserData || state.checkUserData,
      };
    },
    resetTable(state) {
      return {
        ...state,
        data: {
          list: [],
          pagination: { total: 0 },
        },
        queryPara: {},
      };
    },
    resetPayNo(state) {
      return {
        ...state,
        payno: '',
        batchstate: '',
      };
    },
    setRowKey(state, action) {
      return {
        ...state,
        selectedRowKeys: action.selectedRowKeys,
      };
    },
  },
};
