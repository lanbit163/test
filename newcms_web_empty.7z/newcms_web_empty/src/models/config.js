export default {
  namespace: 'config',

  state: {
    cardsize: 'small', // default small
    tablesize: 'middle', // default middle small(自带边框了？)
    cardboard: true, //  card 是否展示边框
    tableboard: true, //   table是否展示边框
    tableColAlign: 'center', // table列居中对齐

    // 维护功能表单的展示方式
    // horizontal:水平对齐 需放开 formItemLayout的注释
    // inline:内联  需放开 formItemLayout的注释
    // vertical:上下对齐(formItemLayout:null)

    // formLayout: 'horizontal',
    // // 1列
    formItemLayoutCol1: {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 10 },
      },
    },

    formLayout: 'inline',
    // 2列
    formItemLayoutCol2: {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 6 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 15 },
      },
    },
    // 3列
    formItemLayoutCol3: {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 8 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 16 },
      },
    },

    // formLayout:'vertical',
    // formItemLayout:null,

    submitFormLayout: {
      // 维护功能 按钮展示方式
      wrapperCol: {
        xs: { span: 24, offset: 0 },
        sm: { span: 10, offset: 7 },
      },
    },
  },
};
