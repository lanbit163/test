import { message } from 'antd';
import * as services from '@/services/api';


export default {
  namespace: 'pubfile',

  state: {},

  effects: {
    *upload({ payload, tempId, realCode, attachtype, returnview }, { call, put }) {
      const response = yield call(
        services.upload,
        `/api/la-file-manages/up/${attachtype}/${tempId}/${realCode}`,
        payload
      );
      if (response.flag !== 'Success') {
        message.error('上传出错');
      } else {
        message.success('上传成功');
        yield put({
          type: `${attachtype}/openView`,
          view: returnview,
        });
      }
    },
    *down({ payload, tempId, attachtype }, { call }) {
      const response = yield call(
        services.post,
        `/api/la-file-manages/query/${attachtype}/${tempId}`,
        null
      );
      if (response.length > 0) {
        yield call(
          services.port,
          `/api/la-file-manages/down/${attachtype}/${tempId}`,
          payload,
          response[0].fileName
        );
      } else {
        message.error('未上传文件，请先上传');
      }
    },
  },

  reducers: {},
};
