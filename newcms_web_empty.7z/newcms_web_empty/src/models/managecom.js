import * as services from '@/services/api';

export default {
  namespace: 'managecom',

  state: {
    orgData: [], // 管理机构清单。全部树形结构
    org02Data: [], // 管理机构分公司清单。非树形
    org03Data: [], // 管理机构中支清单。非树形
    org04Data: [], // 管理机构分公司清单。非树形

    compatTimeLine: [],
    depositEntryTimeLine: [],
    bankAccNoTimeLine: [],
    depositTimeLine: [],
    settleTimeLine: [],
    chargeRateTimeLine: [],
    rechargeTimeLine: [],
    depositMaintenanceTimeLine: [],
    writeAuditTimeLine: [],
    ladderRateTimeLine: [],
    chargeRateModifyTimeLine: [],
  },

  effects: {
    // 查询机构清单
    // 目前仅支持参数为空或参数为orgGrade。查询指定层级的机构清单
    *fetchorg({ queryPara }, { call, put }) {
      const response = yield call(services.post, '/api/org-infos/findData', queryPara);
      if (response) {
        yield put({
          type: 'saveorg',
          payload: response,
          queryPara,
        });
      }
    },

    *timeline({ queryPara }, { call, put }) {
      const response = yield call(services.get, '/api/la-approval-lines/nopage', queryPara);
      if (response) {
        yield put({
          type: 'saveTimeLine',
          payload: response,
          queryPara,
        });
      }
    },

    *settletimeline({ queryPara }, { call, put }) {
      const response = yield call(services.get, '/api/la-settle-lines/nopage', queryPara);
      if (response) {
        yield put({
          type: 'saveSettleTimeLine',
          payload: response,
          queryPara,
        });
      }
    },
  },

  reducers: {
    saveorg(state, action) {
      switch (action.queryPara.orgGrade) {
        case '':
          return { ...state, orgData: action.payload || state.orgData };
        case '02':
          return { ...state, org02Data: action.payload || state.org02Data };
        case '03':
          return { ...state, org03Data: action.payload || state.org03Data };
        case '04':
          return { ...state, org04Data: action.payload || state.org04Data };
        default:
          return { ...state };
      }
    },
    saveTimeLine(state, action) {
      switch (action.queryPara.scene_equals) {
        case 'compact':
          return { ...state, compatTimeLine: action.payload || state.compatTimeLine };
        case 'depositEntryMaintenance':
          return { ...state, depositEntryTimeLine: action.payload || state.depositEntryTimeLine };
        case 'bankAccNo':
          return { ...state, bankAccNoTimeLine: action.payload || state.bankAccNoTimeLine };
        case 'depositCancellation':
          return { ...state, depositTimeLine: action.payload || state.depositTimeLine };
        case 'chargeRate':
          return { ...state, chargeRateTimeLine: action.payload || state.chargeRateTimeLine };
        case 'recharge':
          return { ...state, rechargeTimeLine: action.payload || state.rechargeTimeLine };
        case 'depositMaintenance':
          return {
            ...state,
            depositMaintenanceTimeLine: action.payload || state.depositMaintenanceTimeLine,
          };
        case 'writeAudit':
          return { ...state, writeAuditTimeLine: action.payload || state.writeAuditTimeLine };
        case 'ladderRate':
          return { ...state, ladderRateTimeLine: action.payload || state.ladderRateTimeLine };
        case 'chargeRateModify':
          return {
            ...state,
            chargeRateModifyTimeLine: action.payload || state.chargeRateModifyTimeLine,
          };
        case 'settle':
          return { ...state, settleTimeLine: action.payload || state.settleTimeLine };
        default:
          return { ...state };
      }
    },
    saveSettleTimeLine(state, action) {
      switch (action.queryPara.scene_equals) {
        case 'settle':
          return { ...state, settleTimeLine: action.payload || state.settleTimeLine };
        case 'chargeRate':
          return { ...state, chargeRateTimeLine: action.payload || state.chargeRateTimeLine };
        default:
          return { ...state };
      }
    },
    clearData(state, action) {
      switch (action.clearType) {
        case 'compact':
          return { ...state, compatTimeLine: [] };
        case 'depositEntryMaintenance':
          return { ...state, depositEntryTimeLine: [] };
        case 'bankAccNo':
          return { ...state, bankAccNoTimeLine: [] };
        case 'depositCancellation':
          return { ...state, depositTimeLine: [] };
        case 'rechargeMaintenance':
          return { ...state, rechargeTimeLine: [] };
        case 'depositMaintenance':
          return { ...state, depositMaintenanceTimeLine: [] };
        case 'chargeRate':
          return { ...state, chargeRateTimeLine: [] };
        case 'settle':
          return { ...state, settleTimeLine: [] };
        case 'writeAuditMaintenance':
          return { ...state, writeAuditTimeLine: [] };
        case 'ladderRateMaintenance':
          return { ...state, ladderRateTimeLine: [] };
        case 'chargeRateModify':
          return { ...state, chargeRateModifyTimeLine: [] };
        default:
          return { ...state };
      }
    },
  },
};
