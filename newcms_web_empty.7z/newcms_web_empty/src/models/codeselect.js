import * as services from '@/services/api';

export default {
  namespace: 'codeselect',

  state: {
    orgSelectData: [], // 管理机构清单。非树形

    // 直销渠道销售团队编码
    laagAgentBranchAttr: [],

    // 证件类型
    cardtype: [],

    // 人员状态
    agentState: [{ code: '01', codeName: '在职' }, { code: '02', codeName: '在职' }, { code: '03', codeName: '离职' }, { code: '04', codeName: '离职' }],

    // 性别
    sex: [{ code: '0', codeName: '男' }, { code: '1', codeName: '女' }],

    // 婚姻状况
    marriage: [{ code: 'N', codeName: '未婚' }, { code: 'Y', codeName: '已婚' }],

    // 审核状态
    approvalStatus: [{ code: '0', codeName: '未审核' }, { code: '1', codeName: '已审核' }],

    // 民族
    nation: [],

    // 学历
    education: [],

    // 政治面貌
    political: [
      { code: '01', codeName: '群众' },
      { code: '02', codeName: '团员' },
      { code: '03', codeName: '党员' },
      { code: '04', codeName: '其他党派' },
    ],

    // 销售组织级别
    branchLevel: [
      { code: '01', codeName: '营业组' },
      { code: '02', codeName: '营业部' },
      { code: '03', codeName: '营业区' },
    ],

    // 渠道区分
    branchType: [
      { code: '01', codeName: '直销' },
      { code: '02', codeName: '银保' },
      { code: '03', codeName: '经代' },
    ],

    // 标志
    flag: [{ code: 'Y', codeName: '是' }, { code: 'N', codeName: '否' }],

    // 标志US
    flagUS: [{ code: 'Y', codeName: 'YES' }, { code: 'N', codeName: 'NO' }],

    // 标志
    learFlag: [{ code: '0', codeName: '无效' }, { code: '1', codeName: '有效' }],

    // 标志2
    learFlagData: [{ code: 'N', codeName: '无效' }, { code: 'Y', codeName: '有效' }],

    // 是否直辖
    upBranchAttr: [{ code: 'N', codeName: '非直辖' }, { code: 'Y', codeName: '直辖' }],

    // 职级
    agentSeries: [],

    // 育成级别
    rearGrade: [
      { code: '01', codeName: '组育成' },
      { code: '02', codeName: '部育成' },
      { code: '03', codeName: '区育成' },
    ],

    agentComData: [],

    // 推荐层级
    recomgensData: [
      { code: '1', codeName: '直接增员' },
      { code: '2', codeName: '间接增员' },
      { code: 'Y', codeName: '全部增员' },
    ],
    // 证件类型
    idCard: [
      { code: '0', codeName: '居民身份证' },
      { code: '1', codeName: '护照' },
      { code: '2', codeName: '军官证' },
      { code: 'G', codeName: '港澳居民来往内地通行证' },
      { code: 'T', codeName: '台湾居民来往大陆通行证' },
    ],
    // 解约原因
    cmsDepartrsn: [],
    // 人员新增 中的账号信息中的   银行省份
    cmsBankprovince: [],
    // 人员新增 中的账号信息中的   类型
    cmsAccounttype: [],

    // 籍贯// 户口所在地
    cmsnativePlace: [],

    // 请假类型
    cmsHolsaclass: [],

    // 离职状态
    departState: [{ code: '0', codeName: '准离职' }, { code: '1', codeName: '离职' }],

    // 职级调整原因
    reason: [],

    // 账号类型
    typeCount: [{ code: '01', codeName: '主账户' }],

    // 审核状态
    chackState: [],

    // 银行
    cmsBankName: [],
    // 行为性质
    punNo: [],

    // 行为类别
    punType: [],

    // 处理方式
    deal: [],
  },

  effects: {
    // 通用查询码表的方法
    // 三个参数。codetype\codeCondition\conditionField
    *codequery({ queryPara }, { call, put }) {
      const response = yield call(services.post, '/api/ld-codes/codequery', queryPara);
      if (response) {
        yield put({
          type: 'codequerycallback',
          payload: response,
          queryPara,
        });
      }
    },
  },

  reducers: {
    codequerycallback(state, action) {
      switch (action.queryPara.codeType) {
        case 'managecom':
          return { ...state, orgSelectData: action.payload || state.orgSelectData };
        case 'agentSeries':
          return { ...state, agentSeries: action.payload || state.agentSeries };
        case 'nation':
          return { ...state, nation: action.payload || state.nation };
        case 'education':
          return { ...state, education: action.payload || state.education };
        case 'cardtype':
          return { ...state, cardtype: action.payload || state.cardtype };
        case 'cmsdepartrsn':
          return { ...state, cmsDepartrsn: action.payload || state.cmsDepartrsn };
        case 'cms_bankprovince':
          return { ...state, cmsBankprovince: action.payload || state.cmsBankprovince };
        case 'cms_accounttype':
          return { ...state, cmsAccounttype: action.payload || state.cmsAccounttype };
        case 'cmsnativePlace':
          return { ...state, cmsnativePlace: action.payload || state.cmsnativePlace };
        case 'cmsHolsaclass':
          return { ...state, cmsHolsaclass: action.payload || state.cmsHolsaclass };
        case '01':
          return { ...state, laagAgentBranchAttr: action.payload || state.laagAgentBranchAttr };
        case 'reason':
          return { ...state, reason: action.payload || state.reason };
        case 'chackState':
          return { ...state, chackState: action.payload || state.chackState };
        case 'cmsBankName':
          return { ...state, cmsBankName: action.payload || state.cmsBankName };
        case 'punNo':
          return { ...state, punNo: action.payload || state.punNo };
        case 'punType':
          return { ...state, punType: action.payload || state.punType };
        case 'deal':
          return { ...state, deal: action.payload || state.deal };
        default:
          return { ...state };
      }
    },
  },
};
