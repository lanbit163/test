export default {
  namespace: 'rowSelection',
  state: {
    selectedRowKeys: [],
    selectedRows: [],
  },

  reducers: {
    changeOptions(state, action) {
      return {
        ...state,
        selectedRowKeys: action.selectedRowKeys || state.selectedRowKeys,
        selectedRows: action.selectedRows || state.selectedRows,
      };
    },
    resetTable(state) {
      return {
        ...state,
        selectedRowKeys: [],
        selectedRows: [],
      };
    },
  },
};
