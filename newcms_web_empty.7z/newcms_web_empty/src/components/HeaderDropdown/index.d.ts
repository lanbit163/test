import * as React from 'react';
export default class HeaderDropdown extends React.Component<any, any> {}
