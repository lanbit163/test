import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { Timeline } from 'antd';
import * as moment from 'moment';

@connect(({ codeselect }) => ({
  codeselect,
}))
class Index extends PureComponent {
  render() {
    const {
      codeselect: { approveStateData },
      timeLineData,
    } = this.props;

    return (
      <Timeline pending="...">
        {timeLineData.map((item, index) => (
          <Timeline.Item key={item.id}>
            {index} . {item.lastModifiedBy} ~{' '}
            {moment(item.lastModifiedDate)
              .utcOffset(0)
              .format('YYYY-MM-DD HH:mm:ss')}{' '}
            ~ {'状态['}
            {Object.keys(approveStateData).map(index2 => {
              if (approveStateData[index2].code === item.status) {
                return approveStateData[index2].codeName;
              }
              return '';
            })}
            {'] ~ 批注['}
            {item.reMarks}
            {']'}
          </Timeline.Item>
        ))}
      </Timeline>
    );
  }
}

export default Index;
