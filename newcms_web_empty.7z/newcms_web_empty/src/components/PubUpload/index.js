import React, { Fragment, PureComponent } from 'react';
import { connect } from 'dva';
import { FormattedMessage } from 'umi/locale';
import { message, Icon, Upload, Button } from 'antd';

@connect(({ pubfile, loading }) => ({
  pubfile,
  loading: loading.models.pubfile,
}))
class Index extends PureComponent {
  state = {
    fileList: [],
  };

  // 从props里获取
  // 1、othernotype（取消按钮时返回到哪个namespace）
  // 2、view（取消按钮时返回到哪个namespace的哪个页面）
  // 3、otherno（给哪个id上传文件）

  handleUpload = () => {
    const { fileList } = this.state;
    const { dispatch, othernotype, otherno, realcode, viewname } = this.props;
    const formData = new FormData();

    if (fileList.length === 0) {
      message.warn('请选择需要上传的文件！');
      return;
    }

    if (fileList.length > 1) {
      message.warn('一次只能上传一个文件！');
      return;
    }

    if (
      (realcode === undefined || realcode === null || realcode === '') &&
      (otherno === undefined || otherno === null || otherno === '')
    ) {
      message.warn('ID为空，请核对！');
      return;
    }

    fileList.forEach(file => {
      formData.append('file', file, encodeURI(file.name));
    });

    dispatch({
      type: 'pubfile/upload',
      payload: formData,
      tempId: otherno === undefined ? 0 : otherno,
      attachtype: othernotype,
      returnview: viewname,
      realCode: realcode === undefined ? '' : realcode,
    });
  };

  render() {
    const { dispatch, othernotype, viewname, loading } = this.props;
    const { fileList } = this.state;
    const props = {
      onRemove: file => {
        this.setState(state => {
          const index = state.fileList.indexOf(file);
          const newFileList = state.fileList.slice();
          newFileList.splice(index, 1);
          return {
            fileList: newFileList,
          };
        });
      },
      beforeUpload: file => {
        this.setState(state => ({
          fileList: [...state.fileList, file],
        }));
        return false;
      },
      fileList,
    };

    return (
      <Fragment>
        <div style={{ textAlign: 'center' }}>
          <div>
            {/* upload的组件，这里限制只能上传一个 */}
            <Upload {...props} disabled={fileList.length > 0}>
              {/* 这里的按钮的disabled是为了把按钮置成灰色 */}
              <Button disabled={fileList.length > 0}>
                <Icon type="upload" /> <FormattedMessage id="global.selectfile" />
              </Button>
            </Upload>
          </div>

          <div style={{ marginTop: '20px' }}>
            <Button type="primary" disabled={loading} onClick={this.handleUpload}>
              <FormattedMessage id="global.upload" />
            </Button>
            <Button
              style={{ marginLeft: 6 }}
              disabled={loading}
              onClick={() => dispatch({ type: `${othernotype}/openView`, view: viewname })}
            >
              <FormattedMessage id="global.cancle" />
            </Button>
          </div>
        </div>
      </Fragment>
    );
  }
}

export default Index;
