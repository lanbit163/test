import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { Card, Table, Icon, Button } from 'antd';
import { formatMessage, FormattedMessage } from 'umi/locale';
import PageHeaderWrapper from '@/components/PageHeaderWrapper';
// import QuerySimple from './querySimple';
import DetailsUp from '@/components/DetailsUp';
import styles from '@/assets/styles/common.less';
import '@/assets/styles/apply.less';

const rowSelection = {
  onChange: (selectedRowKeys, selectedRows) => {
    console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
  },
  getCheckboxProps: record => ({
    disabled: record.name === 'Disabled User', // Column configuration not to be checked
    name: record.name,
  }),
};

@connect(({ detailsUp, loading, config }) => ({
  detailsUp,
  config,
  loading: loading.models.detailsUp,
}))
class Index extends PureComponent {
  state = {
    // selectedRows: [],
    rowSN: 0,
  };

  componentDidMount() {
    const {
      dispatch,
      detailsUp: { currData },
    } = this.props;
    dispatch({
      type: 'detailsUp/resetTable',
      queryPara: {},
    });
    dispatch({
      type: 'detailsUp/fetch1',
      payload: currData,
    });
  }

  columns = () => {
    const { config } = this.props;
    const { rowSN } = this.state;
    return [
      {
        title: formatMessage({ id: 'apply.xh' }),
        width: 50,
        fixed: 'left',
        render(text, record, index) {
          return <span>{rowSN + index + 1}</span>;
        },
        align: config.tableColAlign,
      },
      {
        title: formatMessage({ id: 'apply.jsh' }),
        dataIndex: 'payNo',
        align: config.tableColAlign,
      },
      {
        title: formatMessage({ id: 'apply.xmbm' }),
        dataIndex: 'projectNo',
        align: config.tableColAlign,
      },
      {
        title: formatMessage({ id: 'apply.xmmc' }),
        dataIndex: 'projectName',
        align: config.tableColAlign,
      },
      {
        title: formatMessage({ id: 'apply.glje' }),
        dataIndex: 'proAmount',
        align: config.tableColAlign,
      },
      {
        title: formatMessage({ id: 'apply.gljls' }),
        dataIndex: 'proCount',
        align: config.tableColAlign,
      },
      {
        title: formatMessage({ id: 'apply.tzxje' }),
        dataIndex: 'sumAdjustmentAmount',
        align: config.tableColAlign,
      },
      {
        title: formatMessage({ id: 'apply.tzxjls' }),
        dataIndex: 'countAdjust',
        align: config.tableColAlign,
      },
      {
        title: formatMessage({ id: 'apply.cytzje' }),
        dataIndex: 'cytzje',
        align: config.tableColAlign,
      },

      {
        title: formatMessage({ id: 'apply.cytzjls' }),
        dataIndex: 'cytzjls',
        align: config.tableColAlign,
      },
    ];
  };

  // 翻页
  queryPage = pagination => {
    setTimeout(() => {
      this.setState({
        rowSN: (pagination.current - 1) * 10,
      });
    }, 0);
  };

  render() {
    const {
      detailsUp: { data },
      // loading,
      config,
      dispatch,
    } = this.props;
    // const { selectedRows } = this.state;
    return (
      <PageHeaderWrapper title={<FormattedMessage id="apply.jshxq" />}>
        <Card
          bordered={config.cardboard}
          size={config.cardsize}
          className={styles.card}
          title={
            <div>
              <Icon type="caret-right" />
              <FormattedMessage id="global.query.title" />
            </div>
          }
        >
          <DetailsUp />
        </Card>
        <Card
          bordered={config.cardboard}
          size={config.cardsize}
          className={styles.card}
          title={
            <div>
              <Icon type="caret-right" />
              <FormattedMessage id="global.result.title" />
            </div>
          }
        >
          <Table
            footer={() => (
              <div className="gb">
                <div>
                  <span>
                    <FormattedMessage id="apply.zglje" />：{data.zglje}
                  </span>
                  <span>
                    <FormattedMessage id="apply.zgljls" />：{data.zgljls}
                  </span>
                  <span>
                    <FormattedMessage id="apply.ztzxje" />：{data.ztzxje}
                  </span>
                  <span>
                    <FormattedMessage id="apply.ztzxjls" />：{data.ztzxjls}
                  </span>
                  <span>
                    <FormattedMessage id="apply.zcytzje" />：
                  </span>
                  <span>
                    <FormattedMessage id="apply.zcytzjls" />：
                  </span>
                </div>
              </div>
            )}
            bordered
            rowSelection={rowSelection}
            columns={this.columns()}
            onChange={this.queryPage}
            dataSource={data.list}
          />
        </Card>
        <div className="gb">
          <Button
            type="primary"
            onClick={() => dispatch({ type: 'detailsUp/openView', view: 'home' })}
          >
            <FormattedMessage id="apply.gb" />
          </Button>
        </div>
      </PageHeaderWrapper>
    );
  }
}

export default Index;
