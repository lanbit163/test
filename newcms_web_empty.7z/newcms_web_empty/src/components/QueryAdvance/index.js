import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import { Form, Select, Button, DatePicker } from 'antd';
import { formatMessage, FormattedMessage } from 'umi/locale';
import * as moment from 'moment';
import styles from '@/assets/styles/common.less';

const FormItem = Form.Item;

@connect(({ detailsUp, loading, codeselect, config }) => ({
  detailsUp,
  codeselect,
  config,
  loading: loading.models.detailsUp,
}))
@Form.create({
  onValuesChange: (props, changedValues, allValues) => {
    const { dispatch } = props;

    /* eslint no-param-reassign: ["error", { "props": false }] */
    // disable the eslint rule (in your .eslintrc or just for the function)
    if (allValues.startDate) {
      allValues.startDate = allValues.startDate.format('YYYY-MM-DD');
    }
    if (allValues.startDate1) {
      allValues.startDate1 = allValues.startDate1.format('YYYY-MM-DD');
    }
    if (allValues.endDate) {
      allValues.endDate = allValues.endDate.format('YYYY-MM-DD');
    }
    if (allValues.endDate1) {
      allValues.endDate1 = allValues.endDate1.format('YYYY-MM-DD');
    }
    if (allValues.applyDate) {
      allValues.applyDate = allValues.applyDate.format('YYYY-MM-DD');
    }
    if (allValues.applyDate1) {
      allValues.applyDate1 = allValues.applyDate1.format('YYYY-MM-DD');
    }

    // 提交日期是Instant类型的。toISOString()转换因为时区问题会相差8小时
    if (allValues.createDate) {
      const date = new Date(allValues.createDate.startOf('day').valueOf() + 8 * 3600 * 1000);
      allValues.createDate = date.toISOString();
    }
    if (allValues.createDate1) {
      const date = new Date(allValues.createDate1.endOf('day').valueOf() + 8 * 3600 * 1000);
      allValues.createDate1 = date.toISOString();
    }
    // if (allValues.batchState) {
    //   allValues.batchState = allValues.batchState.join(',');
    // }

    dispatch({
      type: 'compact/saveLaComInfo',
      queryPara: allValues,
    });
  },
})
class Index extends PureComponent {
  componentDidMount() {
    const { dispatch } = this.props;

    // 结算号
    dispatch({
      type: 'codeselect/codequery',
      queryPara: {
        codeType: 'paynumber',
      },
    });

    // 初始化合作机构清单
    dispatch({
      type: 'codeselect/codequery',
      queryPara: {
        codeType: 'agentcom',
      },
    });

    // 初始化真实项目
    dispatch({
      type: 'codeselect/codequery',
      queryPara: {
        codeType: 'rprojectcode',
      },
    });

    dispatch({
      type: 'detailsUp/resetTable',
      queryPara: {},
    });
  }

  handleSearch = e => {
    e.preventDefault();

    const { dispatch, form, clearSelect, cz, zt } = this.props;
    cz();
    form.validateFields((err, fieldsValue) => {
      if (err) return;

      /* eslint no-param-reassign: ["error", { "props": false }] */
      // disable the eslint rule (in your .eslintrc or just for the function)
      if (form.getFieldValue('startDate')) {
        fieldsValue.startDate = form.getFieldValue('startDate').format('YYYY-MM-DD');
      }
      if (form.getFieldValue('startDate1')) {
        fieldsValue.startDate1 = form.getFieldValue('startDate1').format('YYYY-MM-DD');
      }
      if (form.getFieldValue('endDate')) {
        fieldsValue.endDate = form.getFieldValue('endDate').format('YYYY-MM-DD');
      }
      if (form.getFieldValue('endDate1')) {
        fieldsValue.endDate1 = form.getFieldValue('endDate1').format('YYYY-MM-DD');
      }
      if (form.getFieldValue('applyDate')) {
        fieldsValue.applyDate = form.getFieldValue('applyDate').format('YYYY-MM-DD');
      }
      if (form.getFieldValue('applyDate1')) {
        fieldsValue.applyDate1 = form.getFieldValue('applyDate1').format('YYYY-MM-DD');
      }
      // if (form.getFieldValue('batchState')) {
      //   fieldsValue.batchState = fieldsValue.batchState.join(',');
      // }

      clearSelect(); // 查询时清空表格已选择的框。实现方法在home组件，通过props传递

      // 重置表格数据
      dispatch({
        type: 'detailsUp/resetTable',
        queryPara: {},
      });

      // if (operatedType === '01' && fieldsValue.status_in.length === 0) {
      //   // 协议审核，如果此时把状态都清空了，那么就会查询所有的啦。所以这里增加逻辑
      //   fieldsValue.status_in = ['02', '03', '04'];
      // }
      // 进行查询
      if (zt === 'app') {
        fieldsValue.operateType = 'payApplication';
        dispatch({
          type: 'detailsUp/fetch',
          queryPara: fieldsValue,
        });
      } else {
        fieldsValue.operateType = 'payDealing';
        dispatch({
          type: 'detailsUp/fetch',
          queryPara: fieldsValue,
        });
      }
    });
  };

  // 重置按钮
  handleFormReset = () => {
    const { form, dispatch, clearSelect } = this.props;
    dispatch({
      type: 'detailsUp/setRowKey',
      selectedRowKeys: [],
    });
    form.resetFields();
    dispatch({
      type: 'detailsUp/resetTable',
      queryPara: {},
    });

    clearSelect();
  };

  render() {
    const {
      detailsUp: { queryPara },
      form: { getFieldDecorator },
      config,
      codeselect,
    } = this.props;

    const FormLayout = config.formLayout;
    let formClass;
    let itemLayout;
    // const ColCount = 2;
    if (config.formLayout === 'horizontal') {
      formClass = styles.tableListForm;
      itemLayout = config.formItemLayoutCol1;
    } else if (config.formLayout === 'inline') {
      formClass = styles.tableListFormInlineCol2;
      itemLayout = config.formItemLayoutCol2;
      // if (ColCount === 2) {
      //   formClass = styles.tableListFormInlineCol2;
      //   itemLayout = config.formItemLayoutCol2;
      // }
    } else {
      formClass = styles.tableListFormVertical;
    }

    return (
      <Fragment>
        <Form onSubmit={this.handleSearch} layout={FormLayout} className={formClass}>
          {/* 合作机构 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.hzjg" />}>
            {getFieldDecorator('agentCom', { initialValue: queryPara.agentCom })(
              <Select
                placeholder={
                  formatMessage({ id: 'global.select.placeholder' }) +
                  formatMessage({ id: 'apply.hzjg' })
                }
                style={{ width: '100%' }}
                showSearch
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children.toString().indexOf(input) >= 0
                }
                allowClear
              >
                {codeselect.agentComData.map(item => (
                  <Select.Option key={item.code}>
                    {item.code}-{item.codeName}
                  </Select.Option>
                ))}
              </Select>
            )}
          </FormItem>
          {/* 渠道 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.qd" />}>
            {getFieldDecorator('branchType', { initialValue: queryPara.branchType })(
              <Select
                placeholder={
                  formatMessage({ id: 'global.select.placeholder' }) +
                  formatMessage({ id: 'apply.qd' })
                }
                style={{ width: '100%' }}
                showSearch
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children.toString().indexOf(input) >= 0
                }
                allowClear
              >
                {codeselect.branchType.map(item => (
                  <Select.Option key={item.code}>
                    {item.code}-{item.codeName}
                  </Select.Option>
                ))}
              </Select>
            )}
          </FormItem>
          {/* 项目 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.xm" />}>
            {getFieldDecorator('projectNo', { initialValue: queryPara.projectNo })(
              <Select
                placeholder={
                  formatMessage({ id: 'global.select.placeholder' }) +
                  formatMessage({ id: 'apply.xm' })
                }
                style={{ width: '100%' }}
                showSearch
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children.toString().indexOf(input) >= 0
                }
                allowClear
              >
                {codeselect.rProjectCodeData.map(item => (
                  <Select.Option key={item.code}>
                    {item.code}-{item.codeName}
                  </Select.Option>
                ))}
              </Select>
            )}
          </FormItem>
          {/* 状态 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.zt" />}>
            {getFieldDecorator('batchState', { initialValue: queryPara.batchState })(
              <Select
                allowClear
                // mode="multiple"
                // placeholder={
                //   formatMessage({ id: 'global.--.placeholder' }) +
                //   formatMessage({ id: 'compact.approvalStatus' }) +
                //   formatMessage({ id: 'global.multiselect.placeholder' }) +
                //   formatMessage({ id: 'global.--.placeholder' })
                // }
                placeholder={
                  formatMessage({ id: 'global.select.placeholder' }) +
                  formatMessage({ id: 'apply.zt' })
                }
                showSearch
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children.toString().indexOf(input) >= 0
                }
                style={{ width: '100%' }}
              >
                {codeselect.batchState.map(item => (
                  <Select.Option key={item.code}>
                    {item.code}-{item.codeName}
                  </Select.Option>
                ))}
              </Select>
            )}
          </FormItem>
          {/* 结算区间起期（起期） */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.jsqjqqqq" />}>
            {getFieldDecorator('startDate', {
              initialValue: queryPara.startDate ? moment(queryPara.startDate) : null,
            })(
              <DatePicker
                style={{ width: '100%' }}
                placeholder={
                  formatMessage({ id: 'global.select.placeholder' }) +
                  formatMessage({ id: 'apply.jsqjqqqq' })
                }
              />
            )}
          </FormItem>
          {/* 结算区间起期（止期） */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.jsqjqqzq" />}>
            {getFieldDecorator('startDate1', {
              initialValue: queryPara.startDate1 ? moment(queryPara.startDate1) : null,
            })(
              <DatePicker
                style={{ width: '100%' }}
                placeholder={
                  formatMessage({ id: 'global.select.placeholder' }) +
                  formatMessage({ id: 'apply.jsqjqqzq' })
                }
              />
            )}
          </FormItem>
          {/* 结算区间止期（起期） */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.jsqjzqqq" />}>
            {getFieldDecorator('endDate', {
              initialValue: queryPara.endDate ? moment(queryPara.endDate) : null,
            })(
              <DatePicker
                style={{ width: '100%' }}
                placeholder={
                  formatMessage({ id: 'global.select.placeholder' }) +
                  formatMessage({ id: 'apply.jsqjzqqq' })
                }
              />
            )}
          </FormItem>
          {/* 结算区间止期（止期） */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.jsqjzqzq" />}>
            {getFieldDecorator('endDate1', {
              initialValue: queryPara.endDate1 ? moment(queryPara.endDate1) : null,
            })(
              <DatePicker
                style={{ width: '100%' }}
                placeholder={
                  formatMessage({ id: 'global.select.placeholder' }) +
                  formatMessage({ id: 'apply.jsqjzqzq' })
                }
              />
            )}
          </FormItem>
          {/* 申请日期起期 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.sqrqqq" />}>
            {getFieldDecorator('applyDate', {
              initialValue: queryPara.applyDate ? moment(queryPara.applyDate) : null,
            })(
              <DatePicker
                style={{ width: '100%' }}
                placeholder={
                  formatMessage({ id: 'global.select.placeholder' }) +
                  formatMessage({ id: 'apply.sqrqqq' })
                }
              />
            )}
          </FormItem>
          {/* 申请日期止期 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.sqrqzq" />}>
            {getFieldDecorator('applyDate1', {
              initialValue: queryPara.applyDate1 ? moment(queryPara.applyDate1) : null,
            })(
              <DatePicker
                style={{ width: '100%' }}
                placeholder={
                  formatMessage({ id: 'global.select.placeholder' }) +
                  formatMessage({ id: 'apply.sqrqzq' })
                }
              />
            )}
          </FormItem>
          {/* 结算号 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.jsh" />}>
            {getFieldDecorator('payNo', { initialValue: queryPara.payNo })(
              <Select
                placeholder={
                  formatMessage({ id: 'global.select.placeholder' }) +
                  formatMessage({ id: 'apply.jsh' })
                }
                style={{ width: '100%' }}
                showSearch
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children.toString().indexOf(input) >= 0
                }
                allowClear
              >
                {codeselect.payNo.map(item => (
                  <Select.Option key={item.code}>{item.codeName}</Select.Option>
                ))}
              </Select>
            )}
          </FormItem>

          <div style={{ overflow: 'hidden' }}>
            <div style={{ textAlign: 'right' }}>
              <Button type="primary" htmlType="submit">
                <FormattedMessage id="global.query" />
              </Button>
              <Button style={{ marginLeft: '20px' }} onClick={this.handleFormReset}>
                <FormattedMessage id="global.reset" />
              </Button>
            </div>
          </div>
        </Form>
      </Fragment>
    );
  }
}

export default Index;
