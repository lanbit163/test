import React, { Fragment, PureComponent } from 'react';
import { connect } from 'dva';
import moment from 'moment';
import { formatMessage, FormattedMessage } from 'umi/locale';
import { Button, Form, Input, Select, Divider } from 'antd';
import styles from '@/assets/styles/common.less';

const FormItem = Form.Item;
const { TextArea } = Input;

@connect(({ approve, loading }) => ({
  approve,
  loading: loading.models.approve,
}))
class Index extends PureComponent {
  handleSubmit = e => {
    const { dispatch, form, selectedIds, scence, namespace, viewname } = this.props;
    e.preventDefault();
    form.validateFieldsAndScroll((err, values) => {
      if (!err) {
        dispatch({
          type: 'approve/batchApprove',
          payload: {
            scence, // 业务场景
            selectedIds, // 选中的记录
            status: values.status, // code_define 表 code_type = 'approveState'。这个字段含义是目标状态
            remark: values.reMarks,
          },
          namespace,
          viewname,
        });
      }
    });
  };

  render() {
    const {
      dispatch,
      namespace,
      viewname,
      loading,
      selectedIds,
      form: { getFieldDecorator },
    } = this.props;

    const formItemLayout = {
      labelCol: {
        xs: { span: 24 },
        sm: { span: 7 },
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 },
        md: { span: 10 },
      },
    };

    const submitFormLayout = {
      wrapperCol: {
        xs: { span: 24, offset: 0 },
        sm: { span: 10, offset: 7 },
      },
    };

    // 仅支持批量审核通过
    return (
      <Fragment>
        <Form
          onSubmit={this.handleSubmit}
          style={{ marginTop: 8 }}
          className={styles.tableListForm}
        >
          <FormItem {...formItemLayout} label={<FormattedMessage id="global.approvalDate" />}>
            {getFieldDecorator('curSysDate', {
              initialValue: moment().format('YYYY-MM-DD'),
            })(<Input disabled />)}
          </FormItem>
          <FormItem {...formItemLayout} label={<FormattedMessage id="global.comments" />}>
            {getFieldDecorator('reMarks', {
              initialValue: selectedIds.length > 1 ? '同意' : undefined,
              rules: [
                {
                  required: false,
                  max: 200,
                },
              ],
            })(
              <TextArea
                placeholder={
                  formatMessage({ id: 'global.input.placeholder' }) +
                  formatMessage({ id: 'global.comments' })
                }
                maxLength="200"
                rows={3}
              />
            )}
          </FormItem>
          <FormItem {...formItemLayout} label={<FormattedMessage id="global.approvalStatus" />}>
            {getFieldDecorator('status', {
              initialValue: selectedIds.length > 1 ? '03' : undefined,
              rules: [
                {
                  required: true,
                  message:
                    formatMessage({ id: 'global.approvalStatus' }) +
                    formatMessage({ id: 'validation.required' }),
                },
              ],
            })(
              <Select
                placeholder={
                  formatMessage({ id: 'global.select.placeholder' }) +
                  formatMessage({ id: 'global.approvalStatus' })
                }
              >
                <Select.Option value="03">03-审核通过</Select.Option>
                <Select.Option value="04" disabled={selectedIds.length > 1}>
                  04-审核退回
                </Select.Option>
              </Select>
            )}
          </FormItem>

          <FormItem {...submitFormLayout} style={{ marginTop: 32 }}>
            <Button type="primary" htmlType="submit" disabled={loading}>
              <FormattedMessage id="global.ok" />
            </Button>
            <Button
              style={{ marginLeft: 8 }}
              onClick={() => dispatch({ type: `${namespace}/openView`, view: viewname })}
              disabled={loading}
            >
              <FormattedMessage id="global.cancle" />
            </Button>
          </FormItem>
        </Form>
        <Divider style={{ margin: '40px 0 24px' }} />
        <div>
          <h3>说明</h3>
          <p>
            仅允许批量审核通过，不允许批量审核退回，当主界面选中记录数超过1条时，审核退回则不可选。
          </p>
        </div>
      </Fragment>
    );
  }
}

export default Index;
