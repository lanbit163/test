import React, { PureComponent, Fragment } from 'react';
import { connect } from 'dva';
import { Form, Select, DatePicker } from 'antd';
import { FormattedMessage } from 'umi/locale';
import moment from 'moment';
import styles from '@/assets/styles/common.less';

const FormItem = Form.Item;
const { Option } = Select;

@connect(({ detailsUp, loading, config, codeselect }) => ({
  detailsUp,
  config,
  codeselect,
  loading: loading.models.detailsUp,
}))
@Form.create()
class Index extends PureComponent {
  componentDidMount() {
    const {
      dispatch,
      detailsUp: { currData },
    } = this.props;
    dispatch({
      type: 'detailsUp/ipt1',
      payload: currData.id,
    });
  }

  render() {
    const {
      detailsUp: { data1 },
      codeselect: { agentComData, payType, batchState, branchType },
      config,
    } = this.props;

    const FormLayout = config.formLayout;
    let formClass;
    let itemLayout;
    // const ColCount = 2;
    if (config.formLayout === 'horizontal') {
      formClass = styles.tableListForm;
      itemLayout = config.formItemLayoutCol1;
    } else if (config.formLayout === 'inline') {
      formClass = styles.tableListFormInlineCol2;
      itemLayout = config.formItemLayoutCol2;
      // if (ColCount === 2) {
      //   formClass = styles.tableListFormInlineCol2;
      //   itemLayout = config.formItemLayoutCol2;
      // }
    } else {
      formClass = styles.tableListFormVertical;
    }

    return (
      <Fragment>
        <Form layout={FormLayout} className={formClass}>
          {/* 合作机构 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.hzjg" />}>
            <Select disabled defaultValue="0" style={{ width: '100%' }}>
              <Option value="0">
                {Object.keys(agentComData).map(index => {
                  if (agentComData[index].code === data1.agentCom) {
                    return `${agentComData[index].code}-${agentComData[index].codeName}`;
                  }
                  return true;
                })}
              </Option>
            </Select>
          </FormItem>
          {/* 渠道 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.qd" />}>
            <Select disabled defaultValue="0" style={{ width: '100%' }}>
              <Option value="0">
                {Object.keys(branchType).map(index => {
                  if (branchType[index].code === data1.branchType) {
                    return `${branchType[index].code}-${branchType[index].codeName}`;
                  }
                  return true;
                })}
              </Option>
            </Select>
          </FormItem>
          {/* 结算区间起期 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.jsqjqq" />}>
            <DatePicker
              disabled
              placeholder=""
              style={{ width: '100%' }}
              value={data1.startDate ? moment(data1.startDate, 'YYYY-MM-DD') : ''}
            />
          </FormItem>
          {/* 结算区间止期 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.jsqjzq" />}>
            <DatePicker
              disabled
              placeholder=""
              style={{ width: '100%' }}
              value={data1.endDate ? moment(data1.endDate, 'YYYY-MM-DD') : ''}
            />
          </FormItem>
          {/* 申请日期 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.sqrq" />}>
            <DatePicker
              disabled
              placeholder=""
              style={{ width: '100%' }}
              value={data1.applyDate ? moment(data1.applyDate, 'YYYY-MM-DD') : ''}
            />
          </FormItem>
          {/* 关联日期 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.glrq" />}>
            <DatePicker
              disabled
              placeholder=""
              style={{ width: '100%' }}
              value={data1.relateDate ? moment(data1.relateDate, 'YYYY-MM-DD') : ''}
            />
          </FormItem>
          {/* 结算日期 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.jsrq" />}>
            <DatePicker
              disabled
              placeholder=""
              style={{ width: '100%' }}
              value={data1.sellteDate ? moment(data1.sellteDate, 'YYYY-MM-DD') : ''}
            />
          </FormItem>
          {/* 审核日期 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.shrq" />}>
            <DatePicker
              disabled
              placeholder=""
              style={{ width: '100%' }}
              value={data1.confirmDate ? moment(data1.confirmDate, 'YYYY-MM-DD') : ''}
            />
          </FormItem>
          {/* 支付日期 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.zfrq" />}>
            <DatePicker
              disabled
              placeholder=""
              style={{ width: '100%' }}
              value={data1.payDate ? moment(data1.payDate, 'YYYY-MM-DD') : ''}
            />
          </FormItem>
          {/* 审核退回日期 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.shthrq" />}>
            <DatePicker
              disabled
              placeholder=""
              style={{ width: '100%' }}
              value={data1.d1 ? moment(data1.d1, 'YYYY-MM-DD') : ''}
            />
          </FormItem>
          {/* 撤销日期 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.cxrq" />}>
            <DatePicker
              disabled
              placeholder=""
              style={{ width: '100%' }}
              value={data1.d2 ? moment(data1.d2, 'YYYY-MM-DD') : ''}
            />
          </FormItem>
          {/* 支付方式 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.zffs" />}>
            <Select disabled defaultValue="0" style={{ width: '100%' }}>
              <Option value="0">
                {Object.keys(payType).map(index => {
                  if (payType[index].code === data1.settleMentType) {
                    return `${payType[index].code}-${payType[index].codeName}`;
                  }
                  return true;
                })}
              </Option>
            </Select>
          </FormItem>
          {/* 状态 */}
          <FormItem {...itemLayout} label={<FormattedMessage id="apply.zt" />}>
            <Select disabled defaultValue="0" style={{ width: '100%' }}>
              <Option value="0">
                {Object.keys(batchState).map(index => {
                  if (batchState[index].code === data1.batchState) {
                    return `${batchState[index].code}-${batchState[index].codeName}`;
                  }
                  return true;
                })}
              </Option>
            </Select>
          </FormItem>
        </Form>
      </Fragment>
    );
  }
}

export default Index;
